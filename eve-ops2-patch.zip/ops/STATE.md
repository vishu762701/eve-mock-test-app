# EVE STATE (read first; every job updates it inside its patch)

PIN: Telegram-Android-master.zip commit 21f7d109da6ab3506c9e9577f98c6a38771ab335 (TelegramMessenger/Telegram-Android), dated 2026-11-12.
REPO: github.com/vishu762701/eve-mock-test-app (main). Written 2026-11-19 by Claude after reviewing repo commit dd110cb7 + the unapplied patch eve-F2-F4a-patch.zip.

## DONE
- J0 re-pin + port gate + port-smoke job; J0b recipes in the gate (Antigravity/Flash).
- F1 data/core: Theme, AndroidUtilities, LocaleController, ApplicationLoader, BuildVars, FileLog, Utilities, ThemeColors, DispatchQueue* (recipes, rebuilt byte-identical by Claude).
- F2 ActionBar family: ActionBar, ActionBarMenu, ActionBarMenuItem, ActionBarMenuSubItem, ActionBarPopupWindow, BackDrawable, MenuDrawable, SimpleTextView (Flash did the sub-items, Gemini "Neon" the three big ones in eve-F2-F4a-patch.zip).
- F3 (partial): BaseFragment, INavigationLayout, ThemeDescription, AlertDialog, BottomSheet, `TelegramHostActivity` (single-fragment host in com.eve.app).
- F4a (partial): EditTextBoldCursor, AnimatedFloat, progress drawables, me.vkryl animators, header/popup/sheet shadows and drawables (16 res files, byte-identical).

## VERIFIED BY CLAUDE (static only)
24 recipes rebuild byte-identical from the real zip; 31 verbatim java files identical; 16 res files identical; 0 unresolved org.telegram/me.vkryl imports; R shim covers all 28 references and every shim target exists;
no duplicate resources; gate (pre-patch rules) passes; additions to strings/themes are additive only.

## NOT VERIFIED
Compile (JUDGE = GitHub), runtime, smoke on the patched head, how the screen looks and feels on the phone.

## BACKLOG (nothing is skipped silently)
B1 OPEN  known_debt flags are still set for 13 files that are now recipe-built (ActionBar, ActionBarMenu, ActionBarMenuItem, BaseFragment, INavigationLayout, ThemeDescription, EditTextBoldCursor, Theme, AndroidUtilities, LocaleController, ApplicationLoader, R.java, ChangeNameActivity) -> clear after green build.
B2 OPEN  `org/telegram/ui/ChangeNameActivity.java` is the old pilot copy (95.8% originality, older revision, EVE-PATCH lines) -> rebuild through a recipe from the pinned zip (FIX-C1).
B3 OPEN  `TelegramHostActivity` implements INavigationLayout with no-op parts (presentFragment=false, no swipe-back, no nested navigation) -> decide real ActionBarLayout (CUT) before Settings/Profile (F3b).
B4 OPEN  SCREEN_SPECS (what to record into the manifest) lives inside tools/port_gate.py, a guard file -> move to docs/port-specs.json so patches stop touching the gate.
B5 OPEN  RLottieNative differs from upstream and is allow-listed as "not a Telegram class", but upstream has a 306-line RLottieNative -> rebuild by recipe or justify honestly.
B6 OPEN  F1 leaks from review: Theme.setDrawableColor lost branches (ShapeDrawable), 13 "no-op" patch-lines and ~33 more in recipes, LocaleController resolves strings via getIdentifier on Eve resources -> audit table + restore real lines where possible (was F1-FIX2).
B7 OPEN  Telegram strings/drawables for the closure of the first screens are partly copied; the rest must be copied byte-identical as needed (R4).
B8 OPEN  UNVERIFIED: smoke/compile of the patched head until GitHub runs it.

## NEXT
1 Owner: add `.github/workflows/apply-patch.yml` and upload `eve-ops-patch.zip` (this folder) -> Run workflow "Apply Patch" (applies the waiting eve-F2-F4a-patch.zip too) -> report build result to the builder/Claude.
2 FIX-C1 (see ops/WORKFLOW.md section 9), then F3b, F4b, C1 screenshots, then the screens list.

## DECISIONS
- Builder = Gemini (code execution in the chat), judge = GitHub, reviewer = Claude, owner = courier.
- Gate rules are judged with the PRE-PATCH tools; patches cannot weaken them.
- Reviewer = Claude; any Claude account can take over from ops/CLAUDE_REVIEWER.md and runs ops/review.py on every upload (recipes rebuilt byte-for-byte, verbatim/resources vs upstream, gates, compile proxy, patch-line audit).
- Exam/admin screens never become Telegram screens; they adopt components in Phase E.

## LOG
2026-11-19 state created by Claude; no job run yet in this workflow.
2026-11-20 added ops/review.py and ops/CLAUDE_REVIEWER.md (second-account handoff).
