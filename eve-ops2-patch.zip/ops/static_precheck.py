#!/usr/bin/env python3
"""static_precheck.py [repo_dir]  -- compile PROXY (no javac needed). Run before every patch.

Checks:
 1 every `import org.telegram.*` / `import me.vkryl.*` in ANY java/kt file resolves to a file in the repo
 2 every `R.<type>.<name>` used by org/telegram + me/vkryl java is declared in org/telegram/messenger/R.java (EVE-SHIM)
   and every shim entry points to an existing Eve resource
 3 no duplicate resource names inside the same values* folder (strings, styles, colors, dimens, ids...)
 4 braces/parentheses balance and `package` matches the folder for each java file under org/telegram and me
 5 warns about TODO/FIXME comments inside org/telegram or me (allowed only when they are unmodified upstream lines)
Exit code 1 on any error. A PASS here does NOT prove it compiles; GitHub Actions is the compiler.
"""
import os, re, sys

repo = sys.argv[1] if len(sys.argv) > 1 else "."
J = os.path.join(repo, "app/src/main/java")
RES = os.path.join(repo, "app/src/main/res")
errors = []
warnings = []


def read(p):
    return open(p, encoding="utf-8", errors="ignore").read()


_TGCUT = None


def mask(src):
    global _TGCUT
    if _TGCUT is None:
        import importlib.util
        here = os.path.dirname(os.path.abspath(__file__))
        for cand in (os.path.join(here, "tgcut.py"), os.path.join(repo, "ops", "tgcut.py"), os.path.expanduser("~/tg-tools/tgcut.py")):
            if os.path.exists(cand):
                spec = importlib.util.spec_from_file_location("tgcut", cand)
                _TGCUT = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(_TGCUT)
                break
        else:
            raise SystemExit("tgcut.py not found next to static_precheck.py")
    return _TGCUT.mask_code(src)


exist = set()
src_files = []
for dp, _, fs in os.walk(J):
    for f in fs:
        if f.endswith((".java", ".kt")):
            p = os.path.join(dp, f)
            src_files.append(p)
            exist.add(os.path.relpath(p, J).rsplit(".", 1)[0].replace(os.sep, "."))

# 1 imports
for p in src_files:
    for m in re.finditer(r"^import\s+(static\s+)?([\w.]+?)(\.\*)?(\s+as\s+\w+)?;?\s*$", read(p), re.M):
        fq = m.group(2)
        if fq.startswith(("org.telegram", "me.vkryl")):
            parts = fq.split(".")
            if not any(".".join(parts[:i]) in exist for i in range(len(parts), 2, -1)):
                errors.append("IMPORT NOT FOUND: %s (in %s)" % (fq, os.path.relpath(p, repo)))

# 2 R shim
shim_path = os.path.join(J, "org/telegram/messenger/R.java")
shim = {}
if os.path.exists(shim_path):
    cls = None
    for l in read(shim_path).split("\n"):
        m = re.search(r"static final class (\w+)", l)
        if m:
            cls = m.group(1)
        m = re.search(r"public static final (?:int|int\[\]) (\w+)\s*=", l)
        if m and cls:
            shim.setdefault(cls, set()).add(m.group(1))
tg_java = []
for root in ("org/telegram", "me"):
    for dp, _, fs in os.walk(os.path.join(J, root)):
        for f in fs:
            if f.endswith(".java"):
                tg_java.append(os.path.join(dp, f))
for p in tg_java:
    if p.endswith(os.path.join("messenger", "R.java")):
        continue
    t = read(p)
    uses_android_r = "import android.R;" in t
    for m in re.finditer(r"(?<![\w.])R\.(string|drawable|id|anim|styleable|style|attr|raw|color|dimen|layout|xml|plurals|array)\.(\w+)", t):
        if uses_android_r:
            continue
        if m.group(2) not in shim.get(m.group(1), set()):
            errors.append("R REF NOT IN SHIM: R.%s.%s (in %s)" % (m.group(1), m.group(2), os.path.relpath(p, repo)))

names = set()
for dp, _, fs in os.walk(RES):
    d = os.path.basename(dp)
    for f in fs:
        b = f.split(".")[0]
        if d.startswith(("drawable", "anim", "layout", "raw", "xml", "color", "mipmap", "animator", "menu", "font")):
            names.add((d.split("-")[0], b))
        if f.endswith(".xml") and d.startswith("values"):
            t = read(os.path.join(dp, f))
            for m in re.finditer(r"<(string|color|dimen|style|attr|item|declare-styleable|integer|bool|array|plurals|string-array)\s+[^>]*?name=\"([\w.]+)\"", t):
                names.add((m.group(1), m.group(2)))
kind = {"string": "string", "drawable": "drawable", "anim": "anim", "style": "style", "styleable": "declare-styleable", "color": "color",
        "dimen": "dimen", "attr": "attr", "raw": "raw", "layout": "layout", "plurals": "plurals", "array": "array", "xml": "xml"}
for c, ns in shim.items():
    for n in ns:
        if c == "id":
            continue
        if (kind.get(c, c), n) not in names:
            errors.append("SHIM TARGET MISSING: R.%s.%s has no Eve resource" % (c, n))

# 3 duplicate resource names in the same values folder
for dp, _, fs in os.walk(RES):
    if not os.path.basename(dp).startswith("values"):
        continue
    seen = {}
    for f in sorted(fs):
        if not f.endswith(".xml"):
            continue
        t = read(os.path.join(dp, f))
        for m in re.finditer(r"<(string|color|dimen|style|integer|bool|array|plurals|string-array|declare-styleable)\s+[^>]*?name=\"([\w.]+)\"", t):
            key = (m.group(1), m.group(2))
            if key in seen and seen[key] != f:
                errors.append("DUPLICATE RESOURCE %s '%s' in %s and %s" % (key[0], key[1], seen[key], f))
            seen.setdefault(key, f)
        for m in re.finditer(r"<item\s+[^>]*type=\"id\"[^>]*name=\"([\w.]+)\"", t):
            key = ("id", m.group(1))
            if key in seen and seen[key] != f:
                errors.append("DUPLICATE ID '%s' in %s and %s" % (m.group(1), seen[key], f))
            seen.setdefault(key, f)

# 4 balance + package, 5 placeholders
for p in tg_java:
    t = read(p)
    code = mask(t)
    if code.count("{") != code.count("}") or code.count("(") != code.count(")"):
        errors.append("UNBALANCED braces/parentheses: " + os.path.relpath(p, repo))
    m = re.search(r"^package\s+([\w.]+);", t, re.M)
    expect = os.path.relpath(os.path.dirname(p), J).replace(os.sep, ".")
    if not m or m.group(1) != expect:
        errors.append("PACKAGE MISMATCH: %s declares %s, folder says %s" % (os.path.relpath(p, repo), m.group(1) if m else None, expect))
    if re.search(r"//\s*(TODO|FIXME)\b", t):
        warnings.append("TODO/FIXME comment in " + os.path.relpath(p, repo) + " (fine if it is an unmodified upstream line)")

if errors:
    print("STATIC PRECHECK FAILED (%d):" % len(errors))
    for e in errors[:80]:
        print("  - " + e)
    sys.exit(1)
for w in warnings[:10]:
    print("  warn: " + w)
print("STATIC PRECHECK PASSED: %d java/kt files, %d telegram/vkryl java files, shim entries %d" % (len(src_files), len(tg_java), sum(len(v) for v in shim.values())))
