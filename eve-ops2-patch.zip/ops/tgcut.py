#!/usr/bin/env python3
"""tgcut.py - copy a REAL Telegram Java file and cut parts of it MECHANICALLY.

The model never retypes upstream code. A "recipe" (small text file, committed in the repo) says:
which upstream file, which methods/statements/imports to remove, which single lines to patch.
`build` replays the recipe on the real upstream file and writes the result. Same recipe + same
upstream = same bytes, so a reviewer (or port_gate) can rebuild and compare.

Recipe lines (one per line, '#' starts a comment, shell-style quoting):
  upstream <path relative to TMessagesProj/src/main/java>
  to <eve path relative to repo root>           (optional; default app/src/main/java/<upstream path>)
  remove-method <name> [params=N] [ptypes=int,Theme.ResourcesProvider] [all]
  remove-statement "<exact text of the first line of a field/statement>"
  remove-import <fully.qualified.Name>
  prune-imports                                  (removes imports whose simple name is no longer used)
  patch-line "<exact existing line>" "<new line>" "<reason>"   (becomes: new line // EVE-PATCH: reason)

Commands:
  tgcut.py build <recipe> [--repo DIR] [--src DIR]
  tgcut.py list-methods <java file> [--touches TLRPC,MessagesController]
  tgcut.py report <eve file> <upstream file>
Environment: TG_SRC = extracted Telegram folder (default ~/tg-src/Telegram-Android-master).
"""
import sys, os, re, shlex, hashlib, difflib, argparse

JAVA_ROOT = "TMessagesProj/src/main/java/"
CTRL = ("if", "for", "while", "switch", "catch", "synchronized", "try", "else", "do", "finally")


def mask_code(src):
    """Return src with comments, strings and char literals blanked (newlines kept)."""
    out = list(src)
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        nx = src[i + 1] if i + 1 < n else ""
        if c == "/" and nx == "/":
            while i < n and src[i] != "\n":
                out[i] = " "
                i += 1
        elif c == "/" and nx == "*":
            while i < n and not (src[i] == "*" and i + 1 < n and src[i + 1] == "/"):
                if src[i] != "\n":
                    out[i] = " "
                i += 1
            for k in (i, i + 1):
                if k < n:
                    out[k] = " "
            i += 2
        elif c == '"' and src.startswith('"""', i):
            out[i] = out[i + 1] = out[i + 2] = " "
            i += 3
            while i < n and not src.startswith('"""', i):
                if src[i] != "\n":
                    out[i] = " "
                i += 1
            for k in range(i, min(i + 3, n)):
                out[k] = " "
            i += 3
        elif c == '"' or c == "'":
            q = c
            out[i] = " "
            i += 1
            while i < n and src[i] != q:
                if src[i] == "\\" and i + 1 < n:
                    out[i] = " "
                    i += 1
                if src[i] != "\n":
                    out[i] = " "
                i += 1
            if i < n:
                out[i] = " "
            i += 1
        else:
            i += 1
    return "".join(out)


def strip_annotations(h):
    prev = None
    while prev != h:
        prev = h
        h = re.sub(r"@\w+(\.\w+)*\s*(\((?:[^()]|\([^()]*\))*\))?", " ", h)
    return h


def classify(header, parent_kind):
    h = header.strip()
    hs = strip_annotations(h).strip()
    if re.search(r"(^|\s)(class|interface|enum)\s+\w+", hs) or hs.startswith("@interface"):
        return "class"
    if parent_kind in ("class", "anon"):
        if hs == "" or hs == "static":
            return "init"
        first = re.match(r"\w+", hs)
        if "(" in hs and first and first.group(0) not in CTRL and re.search(r"\w\s*\((?:.|\n)*\)\s*(throws[\w\s,.<>]+)?$", hs):
            return "method"
        return "expr"
    if re.search(r"\bnew\s+[\w.<>?,\s\[\]]+\((?:.|\n)*\)\s*$", hs):
        return "anon"
    if hs.endswith("=") or re.search(r"=\s*new\s+[\w.<>\[\]]+\s*(\[\s*\])+\s*$", hs):
        return "expr"
    if "->" in hs:
        return "lambda"
    return "code"


def parse_methods(src):
    """Return list of method dicts for every class-body level method with a body."""
    code = mask_code(src)
    lines_starts = [0]
    for m in re.finditer("\n", src):
        lines_starts.append(m.end())

    def line_of(idx):
        lo, hi = 0, len(lines_starts) - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if lines_starts[mid] <= idx:
                lo = mid
            else:
                hi = mid - 1
        return lo + 1

    stack = [{"kind": "file", "stmt": 0, "paren": 0, "open": -1}]
    methods = []
    i, n = 0, len(code)
    while i < n:
        c = code[i]
        top = stack[-1]
        if c == "(":
            top["paren"] += 1
        elif c == ")":
            top["paren"] -= 1
        elif c == ";" and top["paren"] <= 0:
            top["stmt"] = i + 1
        elif c == "{":
            header = code[top["stmt"]:i]
            kind = classify(header, top["kind"])
            hstart = top["stmt"] + (len(header) - len(header.lstrip()))
            stack.append({"kind": kind, "stmt": i + 1, "paren": 0, "open": i, "header": header,
                          "hstart": hstart, "parent": top["kind"]})
        elif c == "}":
            if len(stack) > 1:
                fr = stack.pop()
                stack[-1]["stmt"] = i + 1
                if fr["kind"] == "method":
                    hs = strip_annotations(fr["header"])
                    mm = re.search(r"(\w+)\s*\(", hs)
                    name = mm.group(1) if mm else "?"
                    pstart = hs.index("(", mm.start()) if mm else 0
                    depth, k, params = 0, pstart, ""
                    while k < len(hs):
                        if hs[k] == "(":
                            depth += 1
                        elif hs[k] == ")":
                            depth -= 1
                            if depth == 0:
                                params = hs[pstart + 1:k]
                                break
                        k += 1
                    methods.append({"name": name, "params": params, "hstart": fr["hstart"], "open": fr["open"],
                                    "close": i})
        i += 1
    out = []
    src_lines = src.split("\n")
    for m in methods:
        sl = line_of(m["hstart"])
        el = line_of(m["close"])
        while sl > 1:
            prev = src_lines[sl - 2].strip()
            if prev.startswith(("//", "/*", "*", "@")):
                sl -= 1
            else:
                break
        m["start_line"], m["end_line"] = sl, el
        out.append(m)
    out.sort(key=lambda x: x["start_line"])
    return out


def ptypes(params):
    res, depth, cur = [], 0, ""
    for ch in params:
        if ch == "<":
            depth += 1
        elif ch == ">":
            depth -= 1
        if ch == "," and depth == 0:
            res.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        res.append(cur)
    types = []
    for p in res:
        p = strip_annotations(p).strip()
        p = re.sub(r"\bfinal\b", "", p).strip()
        toks = p.rsplit(None, 1)
        t = toks[0] if len(toks) == 2 else p
        types.append(re.sub(r"\s+", "", t))
    return types


def braces_ok(src):
    code = mask_code(src)
    return code.count("{") == code.count("}") and code.count("(") == code.count(")")


def remove_lines(lines, a, b):
    """Delete lines a..b (1-based, inclusive); collapse one doubled blank line."""
    new = lines[:a - 1] + lines[b:]
    if a - 2 >= 0 and a - 1 < len(new) and new[a - 2].strip() == "" and new[a - 1].strip() == "":
        del new[a - 1]
    return new


def op_remove_method(text, args):
    name = args[0]
    opts = args[1:]
    want_params = None
    want_types = None
    allm = "all" in opts
    for o in opts:
        if o.startswith("params="):
            want_params = int(o.split("=", 1)[1])
        if o.startswith("ptypes="):
            want_types = [re.sub(r"\s+", "", t) for t in o.split("=", 1)[1].split(",") if t]
    ms = [m for m in parse_methods(text) if m["name"] == name]
    if want_params is not None:
        ms = [m for m in ms if len(ptypes(m["params"])) == want_params]
    if want_types is not None:
        ms = [m for m in ms if ptypes(m["params"]) == want_types]
    if not ms:
        raise SystemExit("remove-method %s: no match" % name)
    if len(ms) > 1 and not allm:
        raise SystemExit("remove-method %s: %d matches (add params=/ptypes= or 'all'): %s" % (
            name, len(ms), "; ".join("%d-%d (%s)" % (m["start_line"], m["end_line"], ",".join(ptypes(m["params"]))) for m in ms)))
    lines = text.split("\n")
    for m in sorted(ms, key=lambda x: -x["start_line"]):
        lines = remove_lines(lines, m["start_line"], m["end_line"])
    return "\n".join(lines), len(ms)


def op_remove_statement(text, first_line, allm=False):
    if allm:
        n = 0
        while True:
            lines = text.split("\n")
            hits = [k for k, l in enumerate(lines) if l.strip() == first_line.strip()]
            if not hits:
                break
            for k in hits[1:]:
                lines[k] += "\u0002"          # hide the other matches for this round
            text = op_remove_statement("\n".join(lines), first_line, False).replace("\u0002", "")
            n += 1
        if n == 0:
            raise SystemExit("remove-statement: no match for %r" % first_line)
        return text
    lines = text.split("\n")
    idx = [k for k, l in enumerate(lines) if l.strip() == first_line.strip()]
    if len(idx) != 1:
        raise SystemExit("remove-statement: %d matches for %r (need exactly 1; add 'all' to remove every match)" % (len(idx), first_line))
    start = idx[0]
    code = mask_code("\n".join(lines))
    cl = code.split("\n")
    depth_b = depth_p = 0
    end = start
    for k in range(start, len(cl)):
        for ch in cl[k]:
            if ch == "{":
                depth_b += 1
            elif ch == "}":
                depth_b -= 1
            elif ch == "(":
                depth_p += 1
            elif ch == ")":
                depth_p -= 1
        end = k
        if depth_b <= 0 and depth_p <= 0 and (cl[k].rstrip().endswith(";") or cl[k].rstrip().endswith("}")):
            break
    # keep leading comments/annotations attached
    s = start
    while s > 0 and lines[s - 1].strip().startswith(("//", "/*", "*", "@")):
        s -= 1
    return "\n".join(remove_lines(lines, s + 1, end + 1))


def op_remove_import(text, fq):
    pat = "import %s;" % fq
    lines = text.split("\n")
    keep = [l for l in lines if l.strip() != pat]
    if len(keep) == len(lines):
        raise SystemExit("remove-import: %s not found" % fq)
    return "\n".join(keep)


def op_prune_imports(text):
    code = mask_code(text)
    body_lines = [cl for l, cl in zip(text.split("\n"), code.split("\n")) if not l.strip().startswith("import ")]
    body = "\n".join(body_lines)
    out = []
    removed = 0
    for l in text.split("\n"):
        m = re.match(r"\s*import\s+(static\s+)?([\w.]+?)(\.\*)?;\s*$", l)
        if m and not m.group(3):
            simple = m.group(2).split(".")[-1]
            if not re.search(r"\b%s\b" % re.escape(simple), body):
                removed += 1
                continue
        out.append(l)
    return "\n".join(out), removed


def op_patch_line(text, old, new, reason):
    lines = text.split("\n")
    idx = [k for k, l in enumerate(lines) if l.strip() == old.strip()]
    if len(idx) != 1:
        raise SystemExit("patch-line: %d matches for %r (need exactly 1)" % (len(idx), old))
    k = idx[0]
    indent = lines[k][:len(lines[k]) - len(lines[k].lstrip())]
    lines[k] = "%s%s // EVE-PATCH: %s" % (indent, new.strip(), reason)
    return "\n".join(lines)


def norm_lines(text):
    out = []
    for l in text.split("\n"):
        s = l.strip()
        if not s or s.startswith(("//", "/*", "*")):
            continue
        s = re.sub(r"\s*//\s*EVE-PATCH:.*$", "", s) if "EVE-PATCH" in s and False else s
        out.append(re.sub(r"\s+", " ", s))
    return out


def report(eve_text, up_text):
    a = norm_lines(eve_text)
    b = norm_lines(up_text)
    patched = [l for l in a if "EVE-PATCH" in l]
    a_core = [l for l in a if "EVE-PATCH" not in l]
    sm = difflib.SequenceMatcher(None, a_core, b, autojunk=False)
    matched = sum(bl.size for bl in sm.get_matching_blocks())
    orig = 100.0 * matched / max(1, len(a_core))
    kept = 100.0 * matched / max(1, len(b))
    return {"eve_lines": len(a_core), "patch_lines": len(patched), "upstream_lines": len(b),
            "originality_pct": round(orig, 2), "kept_pct": round(kept, 2)}


def tg_src(arg):
    return os.path.expanduser(arg or os.environ.get("TG_SRC", "~/tg-src/Telegram-Android-master"))


def cmd_build(recipe_path, repo, src):
    rel = to = None
    text = None
    log = []
    with open(recipe_path, encoding="utf-8") as f:
        raw = f.read().split("\n")
    for ln, line in enumerate(raw, 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        t = shlex.split(line)
        op, args = t[0], t[1:]
        if op == "upstream":
            rel = args[0]
            with open(os.path.join(src, JAVA_ROOT, rel), "rb") as f:
                text = f.read().decode("utf-8")
            orig_text = text
        elif text is None:
            raise SystemExit("recipe line %d: 'upstream' must come first" % ln)
        elif op == "to":
            to = args[0]
        elif op == "remove-method":
            text, n = op_remove_method(text, args)
            log.append("removed %d x %s" % (n, args[0]))
        elif op == "remove-statement":
            text = op_remove_statement(text, args[0], "all" in args[1:])
            log.append("removed statement %r" % args[0][:50])
        elif op == "remove-import":
            text = op_remove_import(text, args[0])
        elif op == "prune-imports":
            text, n = op_prune_imports(text)
            log.append("pruned %d imports" % n)
        elif op == "patch-line":
            if len(args) != 3 or not args[2].strip():
                raise SystemExit("recipe line %d: patch-line needs old, new and a reason" % ln)
            text = op_patch_line(text, args[0], args[1], args[2])
            log.append("patched 1 line (%s)" % args[2][:40])
        else:
            raise SystemExit("recipe line %d: unknown op %s" % (ln, op))
        if not braces_ok(text):
            raise SystemExit("recipe line %d (%s): braces/parentheses unbalanced after this step" % (ln, op))
    if rel is None:
        raise SystemExit("recipe has no upstream line")
    dest = os.path.join(repo, to or ("app/src/main/java/" + rel))
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    with open(dest, "wb") as f:
        f.write(text.encode("utf-8"))
    rep = report(text, orig_text)
    sha = hashlib.sha256(text.encode("utf-8")).hexdigest()
    print("BUILT %s" % dest)
    for l in log:
        print("  - " + l)
    print("  result_sha256=%s" % sha)
    print("  upstream_sha256=%s" % hashlib.sha256(orig_text.encode("utf-8")).hexdigest())
    print("  %s" % rep)
    print("  mode=%s" % ("VERBATIM" if text == orig_text else "CUT"))


def cmd_list(path, touches):
    text = open(path, encoding="utf-8").read()
    code = mask_code(text).split("\n")
    names = [t for t in (touches or "").split(",") if t]
    for m in parse_methods(text):
        body = "\n".join(code[m["start_line"] - 1:m["end_line"]])
        hit = [t for t in names if re.search(r"\b%s\b" % re.escape(t), body)]
        print("%d-%d %s(%s) lines=%d%s" % (m["start_line"], m["end_line"], m["name"], ",".join(ptypes(m["params"])),
                                          m["end_line"] - m["start_line"] + 1, ("  TOUCHES:" + ",".join(hit)) if hit else ""))


def main():
    ap = argparse.ArgumentParser(add_help=True)
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build"); b.add_argument("recipe"); b.add_argument("--repo", default="."); b.add_argument("--src")
    l = sub.add_parser("list-methods"); l.add_argument("file"); l.add_argument("--touches")
    r = sub.add_parser("report"); r.add_argument("eve"); r.add_argument("upstream")
    a = ap.parse_args()
    if a.cmd == "build":
        cmd_build(a.recipe, a.repo, tg_src(a.src))
    elif a.cmd == "list-methods":
        cmd_list(a.file, a.touches)
    elif a.cmd == "report":
        print(report(open(a.eve, encoding="utf-8").read(), open(a.upstream, encoding="utf-8").read()))


if __name__ == "__main__":
    main()
