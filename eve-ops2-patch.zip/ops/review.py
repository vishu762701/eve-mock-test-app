#!/usr/bin/env python3
"""review.py - the reviewer's evidence run (what Claude does on every upload). Needs only the Python standard library.

  python3 ops/review.py --repo <repo.zip|dir> --tg <Telegram-Android-master.zip|dir> [--prev <older repo.zip|dir>]

What it does (in this order):
  1 identity     zip commit SHAs, Telegram pin check
  2 diff         changed/added/removed vs --prev, flags for workflows/tools/tests/build files
  3 patches      patch zips waiting in the repo root (eve-*-patch.zip, patches/*.zip): path policy + applied into a scratch copy;
                 every later check runs on the AFTER state, judged with the PRE-PATCH tools (a patch cannot weaken its own judge)
  4 recipes      every docs/port-recipes/*.cut rebuilt from the real Telegram zip and compared byte-for-byte
  5 verbatim     registry + manifest VERBATIM files vs upstream, Telegram-named files with no recipe/verbatim proof
  6 resources    manifest resources vs upstream
  7 gates        port_gate --check --upstream, check_no_shortcuts, static_precheck (compile proxy)
  8 patch-lines  audit of every patch-line in every recipe (no-op, injects logic?)
  9 manifest     modes, known_debt, low kept ratios
 10 guards       did tools/*.py shrink or lose fail/exit lines vs --prev
Prints PASS/WARN/FAIL per check and a verdict. Compile and runtime are NOT checked (GitHub is the compiler, the phone is the judge).
"""
import argparse, hashlib, json, os, re, shlex, shutil, stat, subprocess, sys, tempfile, zipfile

PIN = "21f7d109da6ab3506c9e9577f98c6a38771ab335"
ALLOWED = ("app/src/main/java/", "app/src/main/res/", "app/src/main/AndroidManifest.xml", "app/src/test/", "app/src/androidTest/", "app/build.gradle.kts",
           "docs/port-recipes/", "docs/port-manifest.json", "docs/telegram-", "ops/", "tools/port_gate.py")
HERE = os.path.dirname(os.path.abspath(__file__))
results = []


def add(name, status, detail=""):
    results.append((name, status, detail))
    print("[%s] %s%s" % (status, name, (" - " + detail) if detail else ""))


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def comment(zp):
    try:
        return zipfile.ZipFile(zp).comment.decode("utf-8", "ignore").strip() or "(none)"
    except Exception:
        return "(not a zip)"


def extract(src, dest):
    if os.path.isdir(src):
        shutil.copytree(src, dest, symlinks=False)
    else:
        with zipfile.ZipFile(src) as z:
            for i in z.infolist():
                n = i.filename
                if n.startswith("/") or ".." in n.split("/"):
                    continue
                z.extract(i, dest)
    return dest


def root_of(d, marker):
    if os.path.exists(os.path.join(d, marker)):
        return d
    for c in sorted(os.listdir(d)):
        p = os.path.join(d, c)
        if os.path.isdir(p) and os.path.exists(os.path.join(p, marker)):
            return p
    return d


def files(root, skip=(".git", "build", ".gradle", "ui-renderings", "__pycache__")):
    out = {}
    for dp, dn, fs in os.walk(root):
        dn[:] = [d for d in dn if d not in skip]
        for f in fs:
            p = os.path.join(dp, f)
            out[os.path.relpath(p, root).replace(os.sep, "/")] = p
    return out


def run(cmd, cwd, env=None, timeout=900):
    e = dict(os.environ)
    e.update(env or {})
    r = subprocess.run(cmd, cwd=cwd, env=e, capture_output=True, text=True, timeout=timeout)
    return r.returncode, (r.stdout + r.stderr)


def safe(name):
    if name.startswith("/") or "\\" in name:
        return False
    parts = name.split("/")
    return ".." not in parts and name.startswith(ALLOWED)


def apply_patches(repo):
    """apply waiting patch zips into repo (scratch copy). returns (list, violations)."""
    found = sorted([f for f in os.listdir(repo) if re.match(r"eve-.*-patch\.zip$", f)])
    pd = os.path.join(repo, "patches")
    if os.path.isdir(pd):
        found += ["patches/" + f for f in sorted(os.listdir(pd)) if f.endswith(".zip")]
    bad, applied = [], []
    for pz in found:
        z = zipfile.ZipFile(os.path.join(repo, pz))
        names = [i for i in z.infolist() if not i.is_dir()]
        viol = [i.filename for i in names if not safe(i.filename) or ((i.external_attr >> 16) & 0o170000) == stat.S_IFLNK]
        if viol:
            bad.append("%s: %s" % (pz, ", ".join(viol[:5])))
            continue
        dels = []
        if "ops/DELETE.txt" in z.namelist():
            dels = [l.strip() for l in z.read("ops/DELETE.txt").decode().split("\n") if l.strip()]
            if any(not safe(d) for d in dels):
                bad.append("%s: unsafe delete path" % pz)
                continue
        for i in names:
            if i.filename == "ops/DELETE.txt":
                continue
            dest = os.path.join(repo, i.filename)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with z.open(i) as s, open(dest, "wb") as o:
                shutil.copyfileobj(s, o)
        for d in dels:
            if os.path.exists(os.path.join(repo, d)):
                os.remove(os.path.join(repo, d))
        z.close()
        os.remove(os.path.join(repo, pz))
        applied.append((pz, len(names), len(dels)))
    return applied, bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--tg", required=True)
    ap.add_argument("--prev")
    a = ap.parse_args()
    tmp = tempfile.mkdtemp(prefix="evereview_")
    home = os.path.join(tmp, "home")
    os.makedirs(os.path.join(home, "tg-tools"))

    # 1 identity
    rc = comment(a.repo) if os.path.isfile(a.repo) else "(dir)"
    tc = comment(a.tg) if os.path.isfile(a.tg) else "(dir)"
    add("1 repo zip commit", "PASS", rc)
    add("1 telegram pin", "PASS" if tc == PIN else ("WARN" if tc == "(dir)" else "FAIL"), "%s (pin %s)" % (tc, PIN[:8]))
    repo_orig = root_of(extract(a.repo, os.path.join(tmp, "orig")), "tools")
    tg = root_of(extract(a.tg, os.path.join(tmp, "tg")), "TMessagesProj")
    if not os.path.isdir(os.path.join(tg, "TMessagesProj")):
        add("1 telegram folder", "FAIL", "TMessagesProj not found inside the Telegram zip")
        return finish()
    prev = root_of(extract(a.prev, os.path.join(tmp, "prev")), "tools") if a.prev else None

    # 2 diff
    if prev:
        A, B = files(prev), files(repo_orig)
        new = [r for r in B if r not in A]
        gone = [r for r in A if r not in B]
        chg = [r for r in B if r in A and sha(A[r]) != sha(B[r])]
        add("2 diff vs prev", "PASS", "%d new, %d changed, %d removed" % (len(new), len(chg), len(gone)))
        for label, pref in (("workflows", ".github/"), ("guard tools", "tools/"), ("build files", "build.gradle"), ("backend/functions", "backend/")):
            hit = [r for r in new + chg + gone if r.startswith(pref) or (pref in r and pref == "build.gradle")]
            if hit:
                add("2 changed " + label, "WARN", ", ".join(hit[:6]))
        tests_removed = 0
        for r in chg:
            if "/test/" in r or "/androidTest/" in r:
                ta = len(re.findall(r"\bassert\w*\(", open(A[r], encoding="utf-8", errors="ignore").read()))
                tb = len(re.findall(r"\bassert\w*\(", open(B[r], encoding="utf-8", errors="ignore").read()))
                if tb < ta:
                    tests_removed += ta - tb
        add("2 test assertions", "WARN" if tests_removed else "PASS", "%d assertions removed in changed tests" % tests_removed)

    # 3 patches -> after state
    repo = os.path.join(tmp, "after")
    shutil.copytree(repo_orig, repo, symlinks=False)
    applied, bad = apply_patches(repo)
    if bad:
        add("3 patch policy", "FAIL", "; ".join(bad))
    for pz, n, d in applied:
        add("3 patch applied (scratch)", "PASS", "%s: %d files, %d deletes" % (pz, n, d))
    if not applied and not bad:
        add("3 patches waiting", "PASS", "none")

    # tools: pre-patch judge
    tgcut = os.path.join(repo, "ops", "tgcut.py")
    if not os.path.exists(tgcut):
        tgcut = os.path.join(HERE, "tgcut.py")
    shutil.copy(tgcut, os.path.join(home, "tg-tools", "tgcut.py"))
    env = {"HOME": home, "TG_SRC": tg, "PYTHONDONTWRITEBYTECODE": "1"}
    guard = os.path.join(tmp, "guardrepo")
    os.makedirs(guard)
    shutil.copytree(os.path.join(repo_orig, "tools"), os.path.join(guard, "tools"))
    for e in os.listdir(repo):
        if e not in ("tools", ".git"):
            os.symlink(os.path.join(repo, e), os.path.join(guard, e))

    # 4 recipes
    rdir = os.path.join(repo, "docs", "port-recipes")
    rec = sorted(os.listdir(rdir)) if os.path.isdir(rdir) else []
    outdir = os.path.join(tmp, "rebuilt")
    match = diff = fail = 0
    badl = []
    for r in rec:
        if not r.endswith(".cut"):
            continue
        code, out = run([sys.executable, os.path.join(home, "tg-tools", "tgcut.py"), "build", os.path.join(rdir, r), "--repo", outdir], repo, env)
        m = re.search(r"^BUILT (.+)$", out, re.M)
        if code or not m:
            fail += 1
            badl.append("%s: %s" % (r, out.strip().split("\n")[-1][:90]))
            continue
        rel = os.path.relpath(m.group(1), outdir)
        if os.path.exists(os.path.join(repo, rel)) and sha(m.group(1)) == sha(os.path.join(repo, rel)):
            match += 1
        else:
            diff += 1
            badl.append("%s: committed file differs from rebuild" % r)
    add("4 recipes rebuilt from real Telegram zip", "PASS" if not (diff or fail) and match else ("FAIL" if (diff or fail) else "WARN"),
        "%d match, %d differ, %d cannot build%s" % (match, diff, fail, ("  | " + "; ".join(badl[:4])) if badl else ""))

    # 5 verbatim
    TGJ = os.path.join(tg, "TMessagesProj/src/main/java")
    TGR = os.path.join(tg, "TMessagesProj/src/main")
    recipe_ups = set()
    for r in rec:
        for l in open(os.path.join(rdir, r), encoding="utf-8"):
            if l.startswith("upstream "):
                recipe_ups.add(l.split()[1].strip().split("/")[-1])
    ok = bad_v = 0
    nolist = []
    reg = os.path.join(repo, "docs/telegram-verbatim-imports.json")
    if os.path.exists(reg):
        for i in json.load(open(reg))["imports"]:
            up = os.path.join(tg, i["upstream"]) if i["upstream"].startswith("TMessagesProj") else os.path.join(TGJ, i["upstream"])
            e = os.path.join(repo, i["eve"])
            if os.path.exists(e) and os.path.exists(up) and sha(e) == sha(up):
                ok += 1
            else:
                bad_v += 1
        add("5 verbatim registry vs upstream", "PASS" if not bad_v else "FAIL", "%d identical, %d not" % (ok, bad_v))
    vj = dv = 0
    for root in ("org/telegram", "me"):
        for dp, _, fs in os.walk(os.path.join(repo, "app/src/main/java", root)):
            for f in fs:
                if not f.endswith(".java"):
                    continue
                p = os.path.join(dp, f)
                rel = os.path.relpath(p, os.path.join(repo, "app/src/main/java"))
                up = os.path.join(TGJ, rel)
                if f in recipe_ups:
                    continue
                if os.path.exists(up) and sha(p) == sha(up):
                    vj += 1
                else:
                    nolist.append(rel)
    add("5 telegram java: verbatim-identical", "PASS", "%d files" % vj)
    add("5 telegram java: not recipe, not identical", "PASS" if not nolist else "WARN", ", ".join(nolist[:8]) or "none")

    # 6 resources + 9 manifest
    man_path = os.path.join(repo, "docs/port-manifest.json")
    if os.path.exists(man_path):
        m = json.load(open(man_path))
        resbad = resok = 0
        modes, debt, low = {}, [], []
        for s in m.get("screens", []):
            for r in s.get("resources", []):
                up = os.path.join(tg, r["upstream"])
                p = os.path.join(repo, r["path"])
                if os.path.exists(up) and os.path.exists(p) and sha(up) == sha(p):
                    resok += 1
                else:
                    resbad += 1
            for f in s["files"]:
                modes[f["mode"]] = modes.get(f["mode"], 0) + 1
                if f.get("known_debt"):
                    debt.append(os.path.basename(f["eve"]))
                if f.get("upstream_lines") and f.get("kept_lines") and f["kept_lines"] < 0.5 * f["upstream_lines"] and f["mode"] == "CUT":
                    low.append("%s %d/%d" % (os.path.basename(f["eve"]), f["kept_lines"], f["upstream_lines"]))
        add("6 manifest resources vs upstream", "PASS" if not resbad else "FAIL", "%d identical, %d not" % (resok, resbad))
        add("9 manifest modes", "PASS", json.dumps(modes))
        add("9 known_debt files", "WARN" if debt else "PASS", "%d: %s" % (len(debt), ", ".join(debt[:12])))
        add("9 CUT files keeping < 50% of upstream", "WARN" if low else "PASS", "; ".join(low[:8]) or "none")
        add("9 screens in manifest", "PASS", ", ".join(s["screen"] for s in m.get("screens", [])))

    # 7 gates (pre-patch tools judge the after state)
    code, out = run([sys.executable, os.path.join(guard, "tools/port_gate.py"), "--check", "--upstream", tg], guard, env)
    last = [l for l in out.strip().split("\n") if l.strip()][-1:] or [""]
    errs = [l.strip() for l in out.split("\n") if "ERROR" in l][:3]
    add("7 port_gate --check --upstream (pre-patch tools)", "PASS" if code == 0 else "FAIL", (last[0] if code == 0 else "; ".join(errs) or last[0])[:200])
    code, out = run([sys.executable, os.path.join(guard, "tools/check_no_shortcuts.py")], guard, env)
    add("7 check_no_shortcuts (pre-patch tools)", "PASS" if code == 0 else "FAIL", out.strip().split("\n")[-1][:160])
    sp = os.path.join(repo, "ops/static_precheck.py")
    if not os.path.exists(sp):
        sp = os.path.join(HERE, "static_precheck.py")
    code, out = run([sys.executable, sp, repo], repo, env)
    add("7 static_precheck (compile proxy)", "PASS" if code == 0 else "FAIL", " | ".join([l.strip() for l in out.strip().split("\n") if "PRECHECK" in l or l.strip().startswith("- ")][:4])[:260])

    # 8 patch-lines audit
    total = noop = 0
    logic = []
    for r in rec:
        for l in open(os.path.join(rdir, r), encoding="utf-8"):
            if not l.startswith("patch-line"):
                continue
            try:
                t = shlex.split(l)
            except ValueError:
                continue
            if len(t) < 4:
                continue
            total += 1
            old, new = t[1], t[2]
            if new.strip().startswith("//") or "no-op" in new:
                noop += 1
            elif re.search(r"getIdentifier|Class\.forName|\.invoke\(|getMethod\(|ActivityThread", new) or new.count("(") > old.count("(") + 1:
                logic.append("%s: %s" % (r[:-4], new.strip()[:70]))
    add("8 patch-lines", "WARN" if (noop or logic) else "PASS", "%d total, %d no-op, %d maybe inject logic%s" % (total, noop, len(logic), (" | " + " ; ".join(logic[:3])) if logic else ""))

    # 10 guards vs prev
    if prev:
        for g in ("tools/port_gate.py", "tools/check_no_shortcuts.py"):
            pa, pb = os.path.join(prev, g), os.path.join(repo, g)
            if os.path.exists(pa) and os.path.exists(pb) and sha(pa) != sha(pb):
                la = open(pa, encoding="utf-8", errors="ignore").read().split("\n")
                lb = set(open(pb, encoding="utf-8", errors="ignore").read().split("\n"))
                lost = [x.strip() for x in la if x not in lb and re.search(r"ERROR|errors\.append|sys\.exit|raise |return 1", x)]
                add("10 guard changed: " + g, "WARN" if lost else "PASS", "%d check/exit lines removed or reworded%s" % (len(lost), (": " + " | ".join(lost[:3])) if lost else " (additions only)"))
    return finish()


def finish():
    f = sum(1 for r in results if r[1] == "FAIL")
    w = sum(1 for r in results if r[1] == "WARN")
    print("\nVERDICT: %s  (%d FAIL, %d WARN, %d PASS)" % ("FIX NEEDED" if f else ("PASS WITH WARNINGS" if w else "PASS"), f, w, len(results) - f - w))
    print("NOT CHECKED: compile (GitHub Actions), runtime, look and feel on the phone.")
    return 1 if f else 0


if __name__ == "__main__":
    sys.exit(main())
