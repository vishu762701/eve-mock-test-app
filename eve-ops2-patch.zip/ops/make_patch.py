#!/usr/bin/env python3
"""make_patch.py <orig_repo_dir> <work_repo_dir> <job-name> [--out DIR]

Builds `eve-<job>-patch.zip` from the difference between the ORIGINAL repo extract and the WORKING copy:
  - new/changed files -> inside the zip at their repo-relative paths
  - deleted files     -> listed in `ops/DELETE.txt` inside the zip
Only paths under the allowed prefixes are included. Anything else is reported and skipped.
"""
import os, sys, zipfile, hashlib

ALLOWED = ("app/src/main/java/", "app/src/main/res/", "app/src/main/AndroidManifest.xml", "app/src/test/", "app/src/androidTest/",
           "app/build.gradle.kts", "docs/port-recipes/", "docs/port-manifest.json", "docs/telegram-", "ops/", "tools/port_gate.py")
SKIP_DIRS = {".git", "build", ".gradle", "__pycache__", "ui-renderings"}


def walk(root):
    out = {}
    for dp, dn, fs in os.walk(root):
        dn[:] = [d for d in dn if d not in SKIP_DIRS]
        for f in fs:
            p = os.path.join(dp, f)
            out[os.path.relpath(p, root).replace(os.sep, "/")] = p
    return out


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    if len(sys.argv) < 4:
        raise SystemExit(__doc__)
    orig, work, job = sys.argv[1], sys.argv[2], sys.argv[3]
    outdir = "."
    if "--out" in sys.argv:
        outdir = sys.argv[sys.argv.index("--out") + 1]
    a, b = walk(orig), walk(work)
    changed = [r for r in b if (r not in a or sha(a[r]) != sha(b[r]))]
    deleted = [r for r in a if r not in b]
    ok = lambda r: r.startswith(ALLOWED)
    skipped = [r for r in changed + deleted if not ok(r)]
    changed = [r for r in changed if ok(r)]
    deleted = [r for r in deleted if ok(r) and r != "ops/DELETE.txt"]
    name = os.path.join(outdir, "eve-%s-patch.zip" % job)
    with zipfile.ZipFile(name, "w", zipfile.ZIP_DEFLATED) as z:
        for r in sorted(changed):
            z.write(b[r], r)
        if deleted:
            z.writestr("ops/DELETE.txt", "\n".join(sorted(deleted)) + "\n")
    print("PATCH %s: %d new/changed, %d deleted" % (name, len(changed), len(deleted)))
    if skipped:
        print("SKIPPED (outside allowed paths): " + ", ".join(skipped[:20]))


if __name__ == "__main__":
    main()
