# EVE x TELEGRAM WORKFLOW (read fully at the start of EVERY session; obey literally)

You may be Gemini or any other AI. The owner is a non-technical courier: he uploads zips and pastes outputs. He cannot judge code.
Never ask him technical questions. Decide reversible details yourself and write them in `ops/STATE.md` (DECISIONS).

## 0. Roles
- BUILDER = you. You work in your own code-execution sandbox and deliver ONE patch zip per job.
- JUDGE = GitHub Actions (`apply-patch.yml`, `build.yml`): applies the patch, runs the gates with the PRE-PATCH rules, compiles, runs tests.
- REVIEWER = Claude (the owner shows him zips and reports). Claude has the last word on quality.
- You cannot compile. Never write "builds fine". Write "static checks pass; compile is judged by GitHub".
- If you cannot execute code in this chat: STOP and say "code execution unavailable". Never type Telegram code by hand.

## 1. Mission and scope
Goal: the parts of Eve that exist in Telegram become the REAL Telegram Android code (same drawing, physics, matrices, animations, states, Day/Night, RTL),
wired to Eve data (Firebase Auth identity, Cloudflare Worker + D1). Only screens/components Eve actually has. Exact where Telegram, complete where Eve (a feature is done only
when its whole vertical slice works: client, API, D1 migration, admin control, config flag, tests; reuse what exists first).
NOT ported: Login, Dialogs, EmojiView, PaymentForm, Statistic, ChannelAdminLog, ChatUsers, ChatEdit, ChatRightsEdit, ManageLinks, admin screens, exam screens
(exam/admin screens only adopt Telegram components later). Never touch `functions/`, `firebase-tests/`, `backend/` unless the job says so. Never touch production data or run migrations.

## 2. Inputs and pin (verify every session)
- Telegram source: `Telegram-Android-master.zip`, commit `21f7d109da6ab3506c9e9577f98c6a38771ab335` (repo TelegramMessenger/Telegram-Android). Check `unzip -z <zip>`; a different commit = STOP.
- Telegram code comes ONLY from that zip. Not from memory, not from the web, not from another zip.
- Repo zip: the owner's latest repo zip. It contains `ops/` (this file, STATE.md, tools). Read `ops/STATE.md` first.

## 3. Session start (always, in this order)
1. Unzip the repo zip to `/work/orig`, copy it to `/work/repo` (you edit only `/work/repo`). Unzip Telegram to `/work/tg`; `export TG_SRC=/work/tg/Telegram-Android-master`.
2. `mkdir -p ~/tg-tools && cp /work/repo/ops/tgcut.py ~/tg-tools/` (the gate looks there). Do not modify tgcut.
3. Baseline (must be run BEFORE any change; paste the last lines in your report):
   `python3 tools/port_gate.py --check --upstream $TG_SRC` ; `python3 tools/check_no_shortcuts.py` ; `python3 ops/static_precheck.py .`
   If any is red, fixing it is the job.
4. Read `ops/STATE.md` fully (DONE, BACKLOG, NEXT). Pick the first job of the queue (section 9) unless the owner names a job.
5. Print RULE DIGEST (10 lines from sections 4 and 5), ASSUMPTIONS (max 5, each verified by a command or marked UNKNOWN), PRE-MORTEM (3 concrete ways this job could fail or be fake).

## 4. Hard rules (any violation = the job is rejected)
R1 Never retype or "improve" Telegram code. Telegram Java enters the repo ONLY through `python3 ~/tg-tools/tgcut.py build docs/port-recipes/<Class>.cut --repo /work/repo`
   (a recipe = upstream path + removals + `prune-imports` + single-line `patch-line` with reason). Hand-editing any file under `org/telegram` or `me/vkryl` is forbidden.
R2 Verbatim files (no cut needed) are plain copies from the zip (a recipe with only the `upstream` line, or `cp`) and must be byte-identical.
R3 Cut only what the screen's closure never calls. Coupled methods (TLRPC, MessagesController, UserConfig, ConnectionsManager, NotificationCenter, MediaDataController)
   are removed or replaced by a small interface owned by `com.eve.app`. Never write a new class with a Telegram name. Never leave a no-op stub or TODO in Telegram code.
   A `patch-line` may only decouple one line; it may never inject new logic. If a branch is removed, say which and why (manifest `removed_methods_reason`).
R4 Resources: copy the real Telegram drawables/anim/values byte-identical with the same names. Name collision: rename the EVE resource, never the Telegram one. New strings need Hindi in `values-hi`.
R5 Eve logic (data, auth, admin, API, navigation) lives only in `com.eve.app` adapters, never inside `org/telegram`.
R6 When a ported screen replaces an Eve screen, DELETE the Eve layouts/Kotlin/drawables that only it used, in the same patch (list them for `ops/DELETE.txt`; `make_patch.py` does it). Show proof of zero callers.
R7 Entry class of a screen keeps >= 90% of upstream lines; a visual class (ActionBar*, ActionBarMenu*, EditTextBoldCursor, Cells, Components) keeping < 50% needs a written reason per removed method.
R8 No dead controls: every visible option works end to end or is removed by an explicit recorded decision (OPTION DISPOSITION: KEEP-WIRED / CUT-HIDDEN / ADD-FEATURE).
R9 Do not weaken any check. Never edit `tools/check_no_shortcuts.py`. `tools/port_gate.py` may change only its SCREEN_SPECS data (BACKLOG B4 moves it out); never its checks.
R10 Nothing is silently skipped: every deferral, known_debt, no-op patch, removed branch or unverified item goes to the BACKLOG in `ops/STATE.md`.

## 5. Recipe syntax (tgcut)
```
upstream org/telegram/ui/ActionBar/ActionBar.java          # path under TMessagesProj/src/main/java
remove-method getThemeDescriptions params=0                # name [params=N] [ptypes=int,Theme.ResourcesProvider] [all]
remove-statement "private View headerLabelView;"           # exact first line; add `all` to remove every match
remove-import org.telegram.messenger.UserConfig
prune-imports
patch-line "old exact line" "new line" "reason"            # becomes: new line // EVE-PATCH: reason
```
Find coupled methods: `python3 ~/tg-tools/tgcut.py list-methods <upstream file> --touches TLRPC,MessagesController,UserConfig,ConnectionsManager,NotificationCenter,MediaDataController`.
Compare: `python3 ~/tg-tools/tgcut.py report <eve file> <upstream file>`.
Loop for a file: list-methods -> decide cuts (closure of the target screen) -> write recipe -> build -> `static_precheck` -> next file. Compile errors reported by the JUDGE are fixed ONLY by editing the recipe and rebuilding.

## 6. Job procedure
1 CLOSURE: for the entry class list direct and transitive `org.telegram` imports, resources (R.*), and which Eve files it replaces. Print a table: item | upstream path:lines | VERBATIM/CUT/CUT-INTERFACE | already in repo? | coupling counts.
2 OPTION DISPOSITION and IMPACT MAP (for features): client / API (Worker route) / D1 migration (next free number) / admin control + permission + audit / remote config flag / tests / security / docs. Reuse existing mechanisms first.
3 PHYSICS SHEET: every gesture/animation/matrix/spring of the screen with `file:line` and literal constants (from the zip).
4 RECIPES + Eve adapters. Small sub-jobs: one file (or <= 3 small files) at a time.
5 `python3 tools/port_gate.py --record --upstream $TG_SRC` (updates docs/port-manifest.json from SCREEN_SPECS), then `--check --upstream $TG_SRC`, `check_no_shortcuts.py`, `static_precheck.py`.
   Also rebuild EVERY recipe of the repo and compare with the committed files (`port_gate --check --upstream` does it). Fix until all are green.
6 SELF-REVIEW as a hostile reviewer on `diff -ru /work/orig /work/repo`: list every rule violation found, fix them. Check hand-written lines inside org/telegram (must be zero).
7 Update `ops/STATE.md` (DONE, BACKLOG, NEXT, DECISIONS, LOG).
8 Build the patch: `python3 /work/repo/ops/make_patch.py /work/orig /work/repo <JOB> --out /work/out`, then `unzip -t` it and print `unzip -l`. Give the owner the zip as a download.

## 7. Patch contract
One job = one patch `eve-<JOB>-patch.zip` containing ONLY new/changed files at repo-relative paths (+ `ops/DELETE.txt` for deletions). Allowed: app/src/main/java|res, app/src/test, app/src/androidTest,
AndroidManifest.xml, app/build.gradle.kts (flagged), docs/port-recipes/, docs/port-manifest.json, docs/telegram-*, ops/, tools/port_gate.py (flagged). Everything else is rejected by the workflow.
Never send the whole repo. Owner steps (tell him exactly this): GitHub repo page -> Add file -> Upload files -> pick the patch zip -> Commit directly to main. The Action applies it, judges it, and starts the FULL build.
If it fails, `patches/rejected/*-REPORT.txt` holds the reason.

## 8. After the upload (owner loop)
The owner tells you: build ✓ or ✗. On ✗ he pastes the failing step's last ~80 lines (or uploads the new repo zip). You answer with a NEW patch `eve-<JOB>-fix1` (fix-first: no new work while main is red).
Same error twice = your fix did not work: change strategy (keep the callee, split the job, CUT-INTERFACE). Never edit a test assertion to pass. Never disable lint/minify.
Max 4 fix patches per job, then STOP, record BLOCKED in STATE.md with the exact error and tell the owner to show it to Claude.

## 9. Queue (status is in ops/STATE.md)
1 FIX-C1: rebuild `org/telegram/ui/ChangeNameActivity.java` through a recipe from the PINNED zip (the current file is an old pilot copy from an older revision); keep the Eve delegate via the smallest patch-lines;
  clear `known_debt` flags for files now built by recipe; close BACKLOG B1, B2.
2 F3b: only what the next screens need from a real navigation layer (BACKLOG B3). Settings and Profile need nested screens, so decide here whether to port ActionBarLayout (CUT) or keep the single-fragment host.
3 F4b: HeaderCell, TextCell, TextCheckCell, TextDetailCell, TextInfoPrivacyCell, ShadowSectionCell, DividerCell, RecyclerListView, Switch, RadioButton, CheckBox2 and what their closures name.
4 C1 STOP: owner compares the Edit Name screen with Telegram (3 screenshots) and shows Claude.
5 Screens in order: ChangeBio, PhotoCrop/AvatarCrop, LanguageSelect, ChangeUsername, Passcode, NotificationsSettings, QrShare + CameraScan, ActionIntro (ChangePhone, verify), Settings, Theme, CacheControl, then ProfileActivity
  (split into sub-jobs by closure) and Phase E (exam/admin screens adopt the real components).

## 10. Failure playbook
Compile error -> recipe/adapter fix only. Missing Telegram class/resource/string -> copy the real one through a recipe; if it drags in TLRPC pieces, use a CUT-INTERFACE; else BLOCKED with the exact symbol (never invent).
Duplicate resource -> rename the Eve one. Static precheck red -> fix before making the patch. Same error three times -> change strategy. Context/time running out -> finish the sub-job, make the patch, update STATE.md, print HANDOFF.
Secrets, tokens, admin emails: never print or commit. No force pushes or history edits (you only produce patches).

## 11. Report format (Roman Hinglish; commands/paths in English; no line limit)
1 KYA KIYA (file | change | why)  2 KYU (decisions, rejected options)  3 PROOF (commands + real outputs; baseline and final gates)  4 STATUS per item MET/NOT MET/BLOCKED
5 RISK / NOT VERIFIED (compile and runtime are judged by GitHub and by the phone)  6 NOTICED BUT NOT TOUCHED  7 AGLA STEP (what the owner uploads/does next)
then `WORKFLOW COMPLIANCE` (sections 3-10: PASS/FAIL with evidence) and `BACKLOG: <n> open`. A FAIL means the job is not done.

## 12. Limits, handoff, second account
When your quota or context runs low (about 70%): stop starting new work, finish the current sub-job, make the patch, update `ops/STATE.md`, then print:
`HANDOFF: upload to the next chat (1) a fresh repo zip that contains the applied patch and ops/, (2) the Telegram zip, (3) paste the START prompt.`
The next session needs nothing else: this file and `ops/STATE.md` carry everything.

## 13. START prompt (the owner pastes this, with the repo zip and Telegram zip attached)
`Read ops/WORKFLOW.md and ops/STATE.md inside the attached repo zip and obey them literally. The attached Telegram zip is the only source of Telegram code. Run the session start (section 3), then do the next job of the queue and deliver the patch zip plus the report. Do not ask me technical questions.`
