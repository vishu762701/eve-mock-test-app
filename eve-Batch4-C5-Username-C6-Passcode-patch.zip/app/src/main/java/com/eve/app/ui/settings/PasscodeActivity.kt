/*
 * Derived from Telegram Android PasscodeActivity.java, Copyright Nikolai Kudashov.
 * GNU GPL v2 or later. See THIRD_PARTY_NOTICES.md.
 */

package com.eve.app.ui.settings

import android.content.Intent
import android.os.Bundle
import com.eve.app.ui.common.TelegramHostActivity
import com.eve.app.util.PasscodeManager

/**
 * Hosts the ported [org.telegram.ui.PasscodeActivity] (Settings, Setup PIN/Password,
 * and Unlock-to-Manage modes) backed by Eve's [PasscodeManager] via [SharedConfig].
 */
class PasscodeActivity : TelegramHostActivity<org.telegram.ui.PasscodeActivity>() {

    override fun onCreate(savedInstanceState: Bundle?) {
        SharedConfig.loadFromEve(this)
        super.onCreate(savedInstanceState)
    }

    override fun createFragment(): org.telegram.ui.PasscodeActivity {
        val defaultMode = if (PasscodeManager.isPasscodeEnabled(this)) {
            org.telegram.ui.PasscodeActivity.TYPE_MANAGE_CODE_SETTINGS
        } else {
            org.telegram.ui.PasscodeActivity.TYPE_SETUP_CODE
        }
        val mode = intent.getIntExtra(EXTRA_PASSCODE_MODE, defaultMode)
        return org.telegram.ui.PasscodeActivity(mode).apply {
            setEveNavigator { nextMode ->
                val nextIntent = Intent(this@PasscodeActivity, PasscodeActivity::class.java)
                    .putExtra(EXTRA_PASSCODE_MODE, nextMode)
                startActivity(nextIntent)
                finish()
            }
        }
    }

    companion object {
        const val EXTRA_PASSCODE_MODE = "eve_passcode_mode"
    }
}
