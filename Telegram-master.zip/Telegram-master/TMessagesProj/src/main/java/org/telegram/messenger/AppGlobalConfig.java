package org.telegram.messenger;

import android.content.SharedPreferences;
import android.text.TextUtils;

import org.telegram.tgnet.TLRPC;

import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class AppGlobalConfig {
    private final HashMap<String, ConfigInternal> map = new HashMap<>();

    public final ConfigInt starsPaidMessagesChannelAmountDefault = ofInt("stars_paid_messages_channel_amount_default", 10);

    public final ConfigInt starsSuggestedPostCommissionPermille = ofInt("stars_suggested_post_commission_permille", 850);
    public final ConfigInt starsSuggestedPostAmountMin = ofInt("stars_suggested_post_amount_min", 5);
    public final ConfigInt starsSuggestedPostAmountMax = ofInt("stars_suggested_post_amount_max", 100000);

    public final ConfigInt tonSuggestedPostCommissionPermille = ofInt("ton_suggested_post_commission_permille", 850);
    public final ConfigLong tonSuggestedPostAmountMin = ofLong("ton_suggested_post_amount_min", 10_000_000L); // 0.01 TON
    public final ConfigLong tonSuggestedPostAmountMax = ofLong("ton_suggested_post_amount_max", 10_000_000_000_000L); // 10000 TON

    public final ConfigTime starsSuggestedPostAgeMin = ofTime("stars_suggested_post_age_min", 86400, TimeUnit.SECONDS);
    public final ConfigTime starsSuggestedPostFutureMin = ofTime("stars_suggested_post_future_min", 300, TimeUnit.SECONDS);
    public final ConfigTime starsSuggestedPostFutureMax = ofTime("stars_suggested_post_future_max", 2678400, TimeUnit.SECONDS);

    public final ConfigDouble tonUsdRate = ofDouble("ton_usd_rate", 3);

    public final ConfigString starsRatingLearnMoreUrl = ofString("stars_rating_learnmore_url", "https://telegram.org/blog/telegram-stars");
    public final ConfigBoolean needAgeVideoVerification = ofBoolean("need_age_video_verification", false);

    public final ConfigInt starsStarGiftResaleCommissionPermille = ofInt("stars_stargift_resale_commission_permille", 800);
    public final ConfigInt tonStarGiftResaleCommissionPermille = ofInt("ton_stargift_resale_commission_permille", 800);
    public final ConfigInt starsStarGiftResaleAmountMin = ofInt("stars_stargift_resale_amount_min", 125);
    public final ConfigInt starsStarGiftResaleAmountMax = ofInt("stars_stargift_resale_amount_max", 35000);
    public final ConfigLong tonStarGiftResaleAmountMin = ofLong("ton_stargift_resale_amount_min", 10_000_000L);
    public final ConfigLong tonStarGiftResaleAmountMax = ofLong("ton_stargift_resale_amount_max", 10_000_000_000_000L);

    public final ConfigInt stargiftsCollectionsLimit = ofInt("stargifts_collections_limit", 100);
    public final ConfigInt stargiftsCollectionGiftsLimit = ofInt("stargifts_collection_gifts_limit", 100);
    public final ConfigInt storiesAlbumsLimit = ofInt("stories_albums_limit", 100);
    public final ConfigInt storiesAlbumStoriesLimit = ofInt("stories_album_stories_limit", 100);

    public final ConfigTime messageTypingDraftTtl = ofTime("message_typing_draft_ttl", 30, TimeUnit.SECONDS);

    public final ConfigTime groupCallMessageTtl = ofTime("group_call_message_ttl", 10, TimeUnit.SECONDS);
    public final ConfigInt groupCallMessageLengthLimit = ofInt("group_call_message_length_limit", 128);

    public final ConfigInt contactNoteLengthLimit = ofInt("contact_note_length_limit", 128);

    public final ConfigInt passkeysAccountPasskeysMax = ofInt("passkeys_account_passkeys_max", 5);

    public final ConfigBoolean settingsDisplayPasskeys = ofBoolean("settings_display_passkeys", BuildVars.DEBUG_VERSION ? true : false);

    public final ConfigBoolean disableBlurInLightTheme = ofBoolean("android_disable_blur_in_light_theme", false);
    public final ConfigBoolean disableBlurInDarkTheme = ofBoolean("android_disable_blur_in_dark_theme", false);

    public final ConfigBoolean audioRecorderV2Disabled = ofBoolean("android_audio_recorder_v2_disabled", false);

    public final ConfigTime noForwardsRequestExpirePeriod = ofTime("no_forwards_request_expire_period", 86400, TimeUnit.SECONDS);
    public final ConfigTime pollClosePeriodMax = ofTime("poll_close_period_max", 86400 * 30, TimeUnit.SECONDS);

    public final ConfigString musicSearchUsername = ofString("music_search_username", null);

    public final ConfigInt pollAnswersMax = ofInt("poll_answers_max", 12);
    public final ConfigInt pollCountriesMax = ofInt("poll_countries_max", 12);
    public final ConfigInt pollAnswerLengthMax = ofInt("poll_answer_length_max", 100);
    public final ConfigInt pollQuestionLengthMax = ofInt("poll_question_length_max", 255);
    public final ConfigInt pollSolutionLengthMax = ofInt("poll_solution_length_max", 200);
    public final ConfigInt pollCaptionLengthMax = ofInt("poll_caption_length_max", 300);

    public final ConfigTime pollAnswerDeletePeriod = ofTime("poll_answer_delete_period", 300, TimeUnit.SECONDS);

    public final ConfigInt botsCreateLimitDefault = ofInt("bots_create_limit_default", 20);
    public final ConfigInt botsCreateLimitPremium = ofInt("bots_create_limit_premium", 40);
    public final ConfigInt botAdditionalUsernamesLimit = ofInt("bot_additional_usernames_limit", 2);

    public final ConfigString phoneCountryIso2 = ofString("phone_country_iso2", "en");

    public final ConfigInt aicomposeToneExamplesNum = ofInt("aicompose_tone_examples_num", 3);
    public final ConfigInt aicomposeToneTitleLengthMax = ofInt("aicompose_tone_title_length_max", 12);
    public final ConfigInt aicomposeTonePromptLengthMax = ofInt("aicompose_tone_prompt_length_max", 1024);
    public final ConfigInt aicomposeToneSavedLimitDefault = ofInt("aicompose_tone_saved_limit_default", 5);
    public final ConfigInt aicomposeToneSavedLimitPremium = ofInt("aicompose_tone_saved_limit_premium", 20);

    public final ConfigBoolean messagePrimaryEditedDate = ofBoolean("message_primary_edited_date", false);

    public final ConfigInt richMessageLengthLimit = ofInt("rich_message_length_limit", 32_768);
    public final ConfigInt richMessageMaxBlocks = ofInt("rich_message_max_blocks", 500);
    public final ConfigInt richMessageMaxDepth = ofInt("rich_message_max_depth", 16);
    public final ConfigInt richMessageMaxMedia = ofInt("rich_message_max_media", 50);
    public final ConfigInt richMessageMaxTableCols = ofInt("rich_message_max_table_cols", 20);
    public final ConfigString richMessagePosting = ofString("rich_message_posting", "premium");

    public final ConfigInt communityPeersLimit = ofInt("community_peers_limit", 100);
    public final ConfigInt communityBotPeersLimit = ofInt("community_bot_peers_limit", 100);

    public final ConfigInt messageLengthLimitDefault = ofInt("message_length_limit_default", 4096);
    public final ConfigInt messageLengthLimitPremium = ofInt("message_length_limit_premium", 8192);

    public final ConfigInt quickReplyMessagesLimit = ofInt("quick_reply_messages_limit", 20);
    public final ConfigInt ephemeralWelcomeMessagesMax = ofInt("ephemeral_welcome_messages_max", 5);

    public final ConfigBoolean roundVideoRecorder2Allowed = ofBoolean("round_video_recorder_2_allowed", true);

    public final ConfigBoolean starsSpendTopUpInvoiceDisabled = ofBoolean("stars_spend_topup_invoice_disabled", false);

    public final ConfigStringSet botAllowedSuffixes = ofStringSet("bot_allowed_suffixes", Collections.singleton("bot"));

    public final ConfigBoolean walletAvailable = ofBoolean("wallet_available", BuildVars.DEBUG_VERSION);
    public final ConfigBoolean walletPaidMessageRecipientMessageAmountCheck = ofBoolean("wallet_paid_message_recipient_message_amount_check", true);
    public final ConfigLong walletTransferMinNanos = ofLong("wallet_transfer_min_nanos", 100_000_000);
    public final ConfigLong walletGaslessMinNanos = ofLong("wallet_gasless_min_nanos", 100_000_000);

    /* * */

    public boolean apply(SharedPreferences.Editor editor, TLRPC.TL_jsonObject object) {
        boolean changed = false;

        for (int a = 0, N = object.value.size(); a < N; a++) {
            final TLRPC.TL_jsonObjectValue value = object.value.get(a);
            final ConfigInternal configHandler = map.get(value.key);
            if (configHandler == null) {
                continue;
            }

            changed |= configHandler.apply(editor, value.value);
        }

        return changed;
    }

    public void load(SharedPreferences preferences) {
        for (ConfigInternal configHandler : map.values()) {
            try {
                configHandler.load(preferences);
            } catch (ClassCastException e) {
                FileLog.e(e);
            }
        }
    }



    /* * */

    private interface ConfigInternal {
        boolean apply(SharedPreferences.Editor editor, TLRPC.JSONValue tlValue);
        void load(SharedPreferences preferences);
    }

    public static class ConfigInt {
        private final Internal handler;

        private ConfigInt(String name, int defaultValue) {
            this.handler = new Internal(name, defaultValue);
        }

        public int get() {
            return handler.value;
        }

        private static class Internal implements ConfigInternal {
            private final String name;
            private final int defaultValue;
            private int value;

            private Internal(String name, int defaultValue) {
                this.name = name;
                this.defaultValue = defaultValue;
            }

            @Override
            public boolean apply(SharedPreferences.Editor editor, TLRPC.JSONValue tlValue) {
                if (tlValue instanceof TLRPC.TL_jsonNumber) {
                    TLRPC.TL_jsonNumber num = (TLRPC.TL_jsonNumber) tlValue;
                    if (num.value != value) {
                        value = (int) num.value;
                        editor.putInt(name, value);
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void load(SharedPreferences preferences) {
                value = preferences.getInt(name, defaultValue);
            }
        }
    }

    public static class ConfigLong {
        private final Internal handler;

        private ConfigLong(String name, long defaultValue) {
            this.handler = new Internal(name, defaultValue);
        }

        public long get() {
            return handler.value;
        }

        private static class Internal implements ConfigInternal {
            private final String name;
            private final long defaultValue;
            private long value;

            private Internal(String name, long defaultValue) {
                this.name = name;
                this.defaultValue = defaultValue;
            }

            @Override
            public boolean apply(SharedPreferences.Editor editor, TLRPC.JSONValue tlValue) {
                if (tlValue instanceof TLRPC.TL_jsonNumber) {
                    TLRPC.TL_jsonNumber num = (TLRPC.TL_jsonNumber) tlValue;
                    if (num.value != value) {
                        value = (long) num.value;
                        editor.putLong(name, value);
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void load(SharedPreferences preferences) {
                value = preferences.getLong(name, defaultValue);
            }
        }
    }

    public static class ConfigDouble {
        private final Internal handler;

        private ConfigDouble(String name, double defaultValue) {
            this.handler = new Internal(name, defaultValue);
        }

        public double get() {
            return handler.value;
        }

        private static class Internal implements ConfigInternal {
            private final String name;
            private final double defaultValue;
            private double value;

            private Internal(String name, double defaultValue) {
                this.name = name;
                this.defaultValue = defaultValue;
            }

            @Override
            public boolean apply(SharedPreferences.Editor editor, TLRPC.JSONValue tlValue) {
                if (tlValue instanceof TLRPC.TL_jsonNumber) {
                    TLRPC.TL_jsonNumber num = (TLRPC.TL_jsonNumber) tlValue;
                    if (num.value != value) {
                        value = num.value;
                        editor.putFloat(name, (float) value);
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void load(SharedPreferences preferences) {
                value = preferences.getFloat(name, (float) defaultValue);
            }
        }
    }

    public static class ConfigString {
        private final Internal handler;

        private ConfigString(String name, String defaultValue) {
            this.handler = new Internal(name, defaultValue);
        }

        public String get() {
            return handler.value;
        }

        public boolean is(String value) {
            return TextUtils.equals(get(), value);
        }

        private static class Internal implements ConfigInternal {
            private final String name;
            private final String defaultValue;
            private String value;

            private Internal(String name, String defaultValue) {
                this.name = name;
                this.defaultValue = defaultValue;
            }

            @Override
            public boolean apply(SharedPreferences.Editor editor, TLRPC.JSONValue tlValue) {
                if (tlValue instanceof TLRPC.TL_jsonString) {
                    TLRPC.TL_jsonString num = (TLRPC.TL_jsonString) tlValue;
                    if (!TextUtils.equals(num.value, value)) {
                        value = num.value;
                        editor.putString(name, value);
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void load(SharedPreferences preferences) {
                value = preferences.getString(name, defaultValue);
            }
        }
    }

    public static class ConfigStringSet {
        private final Internal handler;

        private ConfigStringSet(String name, Set<String> defaultValue) {
            this.handler = new Internal(name, defaultValue);
        }

        public Set<String> get() {
            return handler.value;
        }

        private static class Internal implements ConfigInternal {
            private final String name;
            private final Set<String> defaultValue;
            private Set<String> value;

            private Internal(String name, Set<String> defaultValue) {
                this.name = name;
                this.defaultValue = defaultValue == null ? null : new HashSet<>(defaultValue);
            }

            @Override
            public boolean apply(SharedPreferences.Editor editor, TLRPC.JSONValue tlValue) {
                if (tlValue instanceof TLRPC.TL_jsonArray) {
                    TLRPC.TL_jsonArray array = (TLRPC.TL_jsonArray) tlValue;
                    HashSet<String> newValue = new HashSet<>();
                    for (int i = 0, N = array.value.size(); i < N; i++) {
                        TLRPC.JSONValue item = array.value.get(i);
                        if (item instanceof TLRPC.TL_jsonString) {
                            newValue.add(((TLRPC.TL_jsonString) item).value);
                        }
                    }
                    if (!newValue.equals(value)) {
                        value = newValue;
                        editor.putStringSet(name, new HashSet<>(value));
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void load(SharedPreferences preferences) {
                Set<String> stored = preferences.getStringSet(name, defaultValue);
                value = stored == null ? null : new HashSet<>(stored);
            }
        }
    }

    public static class ConfigBoolean {
        private final Internal handler;

        private ConfigBoolean(String name, boolean defaultValue) {
            this.handler = new Internal(name, defaultValue);
        }

        public boolean get() {
            return handler.value;
        }

        private static class Internal implements ConfigInternal {
            private final String name;
            private final boolean defaultValue;
            private boolean value;

            private Internal(String name, boolean defaultValue) {
                this.name = name;
                this.defaultValue = defaultValue;
            }

            @Override
            public boolean apply(SharedPreferences.Editor editor, TLRPC.JSONValue tlValue) {
                if (tlValue instanceof TLRPC.TL_jsonBool) {
                    TLRPC.TL_jsonBool num = (TLRPC.TL_jsonBool) tlValue;
                    if (num.value != value) {
                        value = num.value;
                        editor.putBoolean(name, value);
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void load(SharedPreferences preferences) {
                value = preferences.getBoolean(name, defaultValue);
            }
        }
    }

    public static class ConfigTime {
        private final ConfigLong.Internal handler;
        private final TimeUnit timeUnit;

        private ConfigTime(String name, TimeUnit timeUnit, long defaultValue) {
            this.handler = new ConfigLong.Internal(name, defaultValue);
            this.timeUnit = timeUnit;
        }

        public long get(TimeUnit timeUnit) {
            return timeUnit.convert(handler.value, this.timeUnit);
        }
    }

    private ConfigInt ofInt(String name, int defaultValue) {
        ConfigInt configInt = new ConfigInt(name, defaultValue);
        map.put(name, configInt.handler);

        return configInt;
    }

    private ConfigLong ofLong(String name, long defaultValue) {
        ConfigLong configInt = new ConfigLong(name, defaultValue);
        map.put(name, configInt.handler);

        return configInt;
    }

    private ConfigDouble ofDouble(String name, double defaultValue) {
        ConfigDouble configDouble = new ConfigDouble(name, defaultValue);
        map.put(name, configDouble.handler);

        return configDouble;
    }

    private ConfigBoolean ofBoolean(String name, boolean defaultValue) {
        ConfigBoolean configBoolean = new ConfigBoolean(name, defaultValue);
        map.put(name, configBoolean.handler);

        return configBoolean;
    }

    private ConfigString ofString(String name, String defaultValue) {
        ConfigString config = new ConfigString(name, defaultValue);
        map.put(name, config.handler);

        return config;
    }

    private ConfigStringSet ofStringSet(String name, Set<String> defaultValue) {
        ConfigStringSet config = new ConfigStringSet(name, defaultValue);
        map.put(name, config.handler);

        return config;
    }

    private ConfigTime ofTime(String name, long defaultValue, TimeUnit timeUnit) {
        ConfigTime configInt = new ConfigTime(name, timeUnit, defaultValue);
        map.put(name, configInt.handler);

        return configInt;
    }

    public static AppGlobalConfig getInstance(int num) {
        return MessagesController.getInstance(num).config;
    }
}
