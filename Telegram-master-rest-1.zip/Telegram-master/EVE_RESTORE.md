# EVE - how to rebuild the full Telegram source tree

Original archive: official Telegram Android source, "Telegram-master.zip", SHA-256 0785365538ce05cf5bdf44a15d8fd5f5219f8193db0a2d124af9665fc63fd7b3
It was split into 6 zips (each under 25 MB) so that it fits in a normal GitHub web upload:

- Telegram-master.zip            : UI + security core (java, res, assets, manifest, jni/tgnet, LICENSE, README)
- Telegram-master-rest-1.zip : remaining files, paths from .gitignore to TMessagesProj/jni/prebuild/lib/armeabi-v7a/libswscale.a
- Telegram-master-rest-2.zip : remaining files, paths from TMessagesProj/jni/prebuild/lib/armeabi-v7a/libtde2e.a to TMessagesProj/jni/prebuild/lib/x86/libvpx.a
- Telegram-master-rest-3.zip : remaining files, paths from TMessagesProj/jni/prebuild/lib/x86/libwallet_engine.a to TMessagesProj/jni/prebuild/lib/x86_64/libvpx.a
- Telegram-master-rest-4.zip : remaining files, paths from TMessagesProj/jni/prebuild/lib/x86_64/libwallet_engine.a to TMessagesProj/libs/libgsaverification-client.aar
- Telegram-master-rest-5.zip : remaining files, paths from TMessagesProj/src/main/assets/emoji.pack to settings.gradle

Rebuild (every zip already contains the top folder Telegram-master/, so extracting all of them into the SAME empty folder restores the original tree):

    mkdir telegram-src
    for z in Telegram-master.zip Telegram-master-rest-*.zip; do unzip -q "$z" -d telegram-src; done

Result: telegram-src/Telegram-master/ = the original tree, byte-identical, except 7 files left out on purpose:
release.keystore, 5x google-services.json, BuildVars.java.
Verify: EVE_MANIFEST_FULL.sha256 (inside Telegram-master-rest-1.zip) lists the SHA-256 of all 13976 files:
    cd telegram-src/Telegram-master && sha256sum -c EVE_MANIFEST_FULL.sha256

Never commit the extracted tree. Read-only reference. GPL license in LICENSE applies.
