package com.eve.app.ui.common

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import androidx.core.content.ContextCompat
import com.eve.app.R
import com.eve.app.util.EveBlurHelper
import com.eve.app.util.EveShapes
import com.google.android.material.tabs.TabLayout
import eightbitlab.com.blurview.BlurView

/**
 * Role-aware iOS 26 chrome container:
 * - [Role.STRUCTURAL_HEADER]: Transparent, rectangular full-width header over the owning screen canvas,
 *   with no blanket capsule clipping, no blur overlay, and no decorative bottom hairline.
 * - [Role.FLOATING_TAB_CONTAINER]: Rounded capsule floating tab container with a single backdrop
 *   material (`@color/eve_tab_floating_backdrop` `#E6FFFFFF` Light / `#E61C1C1E` Dark, opaque fallback
 *   `@color/eve_tab_floating_fallback` `#FFFFFF` Light / `#1C1C1E` Dark) and 0dp outline/separator.
 */
class EveGlassToolbar @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : BlurView(context, attrs, defStyleAttr) {

    enum class Role {
        STRUCTURAL_HEADER,
        FLOATING_TAB_CONTAINER
    }

    private var explicitRoleSet: Boolean = false

    var role: Role = Role.STRUCTURAL_HEADER
        set(value) {
            field = value
            applyRoleConfiguration()
        }

    /** Both structural headers and floating tab containers use 0dp decorative bottom separator. */
    val separatorHeightPx: Float = 0f

    val backdropTintColorRes: Int = R.color.eve_tab_floating_backdrop
    val opaqueFallbackColorRes: Int = R.color.eve_tab_floating_fallback

    private val capsuleOutlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(
                0,
                0,
                view.width,
                view.height,
                EveShapes.capsule(view.height.toFloat())
            )
        }
    }

    init {
        if (attrs != null) {
            val a = context.obtainStyledAttributes(attrs, R.styleable.EveGlassToolbar, defStyleAttr, 0)
            try {
                if (a.hasValue(R.styleable.EveGlassToolbar_eveToolbarRole)) {
                    explicitRoleSet = true
                    val roleInt = a.getInt(R.styleable.EveGlassToolbar_eveToolbarRole, 0)
                    role = if (roleInt == 1) Role.FLOATING_TAB_CONTAINER else Role.STRUCTURAL_HEADER
                }
            } finally {
                a.recycle()
            }
        }
        applyRoleConfiguration()
    }

    override fun onFinishInflate() {
        super.onFinishInflate()
        if (!explicitRoleSet && containsTabChild()) {
            role = Role.FLOATING_TAB_CONTAINER
        }
    }

    override fun addView(child: View?, index: Int, params: ViewGroup.LayoutParams?) {
        super.addView(child, index, params)
        if (!explicitRoleSet && (child is TabLayout || child is EveGlassSegmentedControl)) {
            role = Role.FLOATING_TAB_CONTAINER
        }
    }

    private fun containsTabChild(): Boolean {
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child is TabLayout || child is EveGlassSegmentedControl) return true
        }
        return false
    }

    private fun applyRoleConfiguration() {
        when (role) {
            Role.STRUCTURAL_HEADER -> {
                setBlurEnabled(false)
                clipToOutline = false
                outlineProvider = ViewOutlineProvider.BACKGROUND
                setBackgroundColor(Color.TRANSPARENT)
            }
            Role.FLOATING_TAB_CONTAINER -> {
                outlineProvider = capsuleOutlineProvider
                clipToOutline = true
                if (isAttachedToWindow) {
                    configureFloatingBackdrop()
                } else {
                    setBackgroundColor(ContextCompat.getColor(context, backdropTintColorRes))
                }
            }
        }
        invalidateOutline()
        invalidate()
    }

    private fun configureFloatingBackdrop() {
        val backdrop = rootView as? ViewGroup
        val radiusDp = resources.getDimension(R.dimen.eve_thin_material_blur_radius) / resources.displayMetrics.density
        val overlayColor = ContextCompat.getColor(context, backdropTintColorRes)
        val fallbackColor = ContextCompat.getColor(context, opaqueFallbackColorRes)
        if (backdrop == null) {
            setBlurEnabled(false)
            setBackgroundColor(fallbackColor)
            return
        }
        setBackgroundColor(Color.TRANSPARENT)
        EveBlurHelper.setupBlurView(
            blurView = this,
            rootView = backdrop,
            radiusDp = radiusDp,
            overlayColor = overlayColor,
            fallbackColor = fallbackColor
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!explicitRoleSet && containsTabChild() && role != Role.FLOATING_TAB_CONTAINER) {
            role = Role.FLOATING_TAB_CONTAINER
            return
        }
        if (role == Role.FLOATING_TAB_CONTAINER) {
            configureFloatingBackdrop()
        } else {
            setBlurEnabled(false)
            setBackgroundColor(Color.TRANSPARENT)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // Decorative bottom separator hairline intentionally removed (0dp in both roles).
    }
}
