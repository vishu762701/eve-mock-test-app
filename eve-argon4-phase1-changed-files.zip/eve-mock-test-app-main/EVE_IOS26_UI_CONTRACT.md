# Eve iOS 26 UI contract

## Authority

The current user authorizes full geometry migration on all screens (ADR-009:
Full-screen iOS 26 geometry) and the Argon 4 — Eve Phase 1 App-Wide Background and
Tab-Chrome Correction (ADR-012). This supersedes older visual requirements only for:
- Screen canvas/background consistency.
- Existing navigation/tab background materials and colours.
- Unnecessary decorative chrome lines, capsules and duplicate backgrounds.
- Tab foreground colours required by these changes.

Screen regions, interactions, English strings, theme reveal, Lottie assets/triggers/
sizes and icon files remain protected. Answer-state colours remain unchanged.

Eve interprets Apple's design principles on Android with Material 1.12.0, resource
qualifiers, native sans-serif and BlurView 2.0.6. No UIKit, SF font files or Apple's
proprietary glass renderer are used. Numeric corner radii and material alpha values
below are approved Eve Android interpretations; Apple publishes no proprietary glass
opacity, blur radius or pixel-perfect Android renderer values.

## Verified references

The official Color, Typography, Materials, Tab Bars and WWDC25 references were read:
- https://developer.apple.com/design/human-interface-guidelines/color
- https://developer.apple.com/design/human-interface-guidelines/materials
- https://developer.apple.com/design/human-interface-guidelines/tab-bars
- https://developer.apple.com/videos/play/wwdc2025/284/
- https://developer.apple.com/videos/play/wwdc2025/219/
- https://developer.apple.com/tutorials/data/design/human-interface-guidelines/color.json
- https://developer.apple.com/tutorials/data/design/human-interface-guidelines/typography.json
- https://developer.apple.com/tutorials/data/design/human-interface-guidelines/materials.json

[Extracted Apple rows and source hashes](docs/ios26/APPLE_REFERENCE_ROWS.md) and
saved JSON provide the baseline evidence.

## Colour and backgrounds

| Role | Semantic tokens | Light | Dark |
|---|---|---|---|
| Plain screen canvas | `eve_system_background`, `eve_plain_canvas`, `eve_bg`, `eve_canvas` | `#FFFFFF` | `#000000` |
| Grouped screen canvas | `eve_system_grouped_background`, `eve_grouped_canvas` | `#F2F2F7` | `#000000` |
| Plain secondary background | `eve_secondary_system_background`, `eve_plain_secondary_background`, `eve_secondary_background` | `#F2F2F7` | `#1C1C1E` |
| Plain tertiary background | `eve_tertiary_system_background`, `eve_plain_tertiary_background`, `eve_tertiary_background` | `#FFFFFF` | `#2C2C2E` |
| Grouped secondary background | `eve_secondary_system_grouped_background`, `eve_grouped_secondary_background`, `eve_grouped_card_bg` | `#FFFFFF` | `#1C1C1E` |
| Grouped tertiary background | `eve_tertiary_system_grouped_background`, `eve_grouped_tertiary_background` | `#F2F2F7` | `#2C2C2E` |
| Primary label | `eve_label_primary` | `#000000` | `#FFFFFF` |
| Secondary label | `eve_label_secondary` | `#50505A` | `#C5C5CC` |
| Reference systemBlue / interactive blue text | `eve_system_blue` | `#0088FF` | `#0091FF` |

- **Plain canvas screens**: `MainActivity` (Home), `LoginActivity` (Login), `TestActivity` (active Mock Test), and `ContentDisplayActivity` (Privacy/Terms/Contact reader).
- **Grouped canvas screens**: `SettingsActivity`, `ProfileActivity`, `ResultActivity`, `ResultDetailActivity`, `LeaderboardActivity` (Full Leaderboard), `NotificationsActivity`, `AboutActivity`, all other student grouped list/form/dashboard screens (`HistoryActivity`, `BookmarksActivity`, `MistakesActivity`, `PerformanceActivity`, `PracticeActivity`, `PyqActivity`, `SyllabusActivity`, `FeedbackActivity`, `PremiumActivity`, `PaymentCheckoutActivity`, `ExamTestsActivity`), and all 17 Admin screens (`AdminActivity`, `ManagePremiumActivity`, `EditAboutActivity`, `ManageExamsActivity`, `ManageExistingExamsActivity`, `EditExamActivity`, `GeneratedTestsActivity`, `ManageUsersActivity`, `SendNotificationActivity`, `FlaggedQuestionsActivity`, `FeedbackMessagesActivity`, `ManagePollsActivity`, `AdminAnalyticsActivity`, `ActivityLogActivity`, `ApiUsageActivity`, `AppConfigActivity`, `ManageSyllabusActivity`, `SystemMonitorActivity`).
- **Single source of truth**: `SystemBarHelper.resolveCanvasRole(activity)` and `EveBaseActivity.setContentView(...)` resolve the owning screen canvas and paint both `window` and `android.R.id.content` inset backing from that role without per-Activity `window.setBackgroundDrawableResource(R.color.eve_bg)` overrides.

`eve_system_blue` is the sole default interactive-blue source. Accent text,
on-accent-container, category blue foreground, input focus stroke, selected icons
and links resolve through aliases to it. `eve_accent_text_readable` retains unused
#005BC0 / #72B2FF for a one-line revert of the accent alias.

#0088FF on white is about 3.5:1: a known user-chosen trade-off, below 4.5:1.
Blue on some secondary/tertiary surfaces also falls below 4.5:1. Checks report
these explicit exact-blue exceptions without weakening the threshold for other
text. This is not a claim of AA compliance for blue text. Protected green/red
answer-state and review colours retain their baseline values and meaning.

## Tab appearance and header chrome (Argon 4 — Phase 1)

| Tab / Chrome Role | Token / Drawable | Light | Dark |
|---|---|---|---|
| Floating tab container backdrop (`Result`: Overview / Review / Leaderboard) | `eve_tab_floating_backdrop` | `#E6FFFFFF` | `#E61C1C1E` |
| Floating tab container opaque fallback | `eve_tab_floating_fallback` | `#FFFFFF` | `#1C1C1E` |
| Floating tab selected indicator (`bg_result_segmented_indicator`) | `eve_tab_floating_selected_indicator` / `eve_result_tab_selected` | `#F2F2F7` | `#3A3A3C` |
| Inline section tab neutral track (`Admin`, `Manage Premium`, `Edit About`) | `eve_tab_inline_track` (`bg_tab_segmented_track`) | `#F2F2F7` | `#1C1C1E` |
| Inline section tab selected surface (`bg_tab_segmented_indicator`) | `eve_tab_inline_selected_surface` / `eve_tab_selected_bg` | `#FFFFFF` | `#3A3A3C` |
| Selected tab label / icon | `eve_tab_selected_text` / `eve_result_tab_selected_text` | `#000000` | `#FFFFFF` |
| Unselected tab label / icon | `eve_tab_unselected_text` / `eve_result_tab_text` | `#50505A` | `#C5C5CC` |
| Unselected individual tab background | `tabView.background = null` | Transparent | Transparent |
| Decorative outline & bottom separator on headers/tab tracks | `EveGlassToolbar.separatorHeightPx` / `<stroke>` | `0dp` | `0dp` |

- **`EveGlassToolbar` Role Separation**:
  - `app:eveToolbarRole="structuralHeader"` (default for full-width headers): Rectangular (`clipToOutline = false`), transparent over the owning screen canvas, blur disabled, and `0dp` decorative bottom hairline. Redundant `<View>` divider hairlines immediately below top headers are removed.
  - `app:eveToolbarRole="floatingTabContainer"` (used around `tabLayoutResult` in `activity_result.xml`): Capsule-clipped (`EveShapes.capsule`), single backdrop (`#E6FFFFFF` Light / `#E61C1C1E` Dark; opaque fallback `#FFFFFF` Light / `#1C1C1E` Dark via `EveBlurHelper`), `0dp` border, `0dp` bottom separator, and inner `tabLayoutResult` track kept transparent (`bg_result_segmented_track`) so no double tint occurs.
- **Inline Section Tabs (`AdminActivity`, `ManagePremiumActivity`, `EditAboutActivity`)**:
  - Use `EveGlassTabLayout` with `Widget.Eve.InlineSectionTabs` (`@drawable/bg_tab_segmented_track` + `@drawable/bg_tab_segmented_indicator`, `tabIndicatorGravity="stretch"`, `padding="4dp"`), preserving fixed/scrollable modes, tab labels/order, and callbacks (including `EditAboutActivity` unsaved-edit confirmation).

## Shapes and density

| Shape | Components | Eve implementation |
|---|---|---|
| Capsule | Buttons, chips, segmented tracks and thumbs, single-line search/filter fields, switches, sliders, badges, floating actions and floating tab containers | `ShapeAppearance.Eve.Capsule`, cornerSize 50%; `EveShapes.capsule(heightPx)`; XML drawable fallback `eve_radius_pill` saturates to half bounds |
| Fixed | Cards, grouped containers, tiles, popup menus | 26dp |
| Fixed modal | Sheets and dialogs | 34dp; bottom sheets have top corners only |
| Concentric | Nested surfaces and multiline/form fields | max(4dp, parent radius minus actual padding); 26−12=14dp, 34−16=18dp |

`dimens.xml`, ShapeAppearance styles and `EveShapes.concentric` centralize geometry.
Touch targets are at least 48dp; list rows have a 52dp minimum. Result uses a
56dp segmented track so its 4dp insets leave 48dp targets. Preserve screen
regions and existing responsive sizing. Do not place decorative circles, rings
or tiles behind Lottie animations. Shape fill, outline and clipping must agree.

## Material scope

Glass is restricted to floating tab bars (`EveGlassToolbar` in `floatingTabContainer` role),
popup menus, and modal sheets/dialogs. Full-width structural top headers are transparent
over their owning screen canvas (`structuralHeader` role). Cards, exam/result cards,
list rows, banners and drawer content are opaque. The Sign In prompt's outside area
stays undimmed and unblurred.

Material tokens are documented Android approximations, not Apple numeric values:

| Token | Light tint | Dark tint |
|---|---|---|
| ultraThin | #CCFFFFFF | #CC1C1C1E |
| thin | #D9FFFFFF | #D91C1C1E |
| regular / floating tab backdrop | #E6FFFFFF | #E61C1C1E |
| thick | #F2FFFFFF | #F21C1C1E |

Their raised alpha preserves at least 4.5:1 for primary labels against even an
opposing black/white backdrop. Text, icons and Lottie foregrounds are never blurred.
Device compositor behavior requires native evidence; source-level contrast
calculations alone do not verify hardware rendering.

## Typography

Use semantic `TextAppearance.Eve.*` roles in sp. The verified default sizes are
34/28/22/20/17/17/16/15/13/12/11 for Large Title through Caption 2. Headline is
semibold (Android medium-family approximation). Top-level titles use Large Title;
pushed-screen headers use Headline, 17sp. Preserve the Eve/Device font switch and
independent test-question fitting. Avoid local numeric text-size or literal colour overrides.

## Verification

Preserve protected palette snapshots and native behavior tests. Update superseded
assertions to the authorized contract; never suppress unrelated failures.
Run XML parsing, design-system checks, script tests, Android unit tests, lint, APK
and instrumentation compilation. Both gesture and three-button native suites and
visual evidence enforcement must pass before publishing the sole Eve-debug-apk
artifact. Inspect light/dark evidence, verify the pushed main SHA and Actions status.
Any missing device, screenshot or authenticated-flow evidence must be reported plainly.

## Shared foundation retained

`Theme.Eve.Foundation` continues to own the 26 semantic colour attributes, shared
Material typography, widgets, disabled states and surface hierarchy. Existing
Recovery names remain aliases into this foundation. General error/offline text
and protected test states keep their own semantic colours; blue is an interaction
role. The higher-contrast overlay retains stronger labels, outlines and fills;
its blue-text alias follows the current user's systemBlue choice.

Importance remains independent of type size. Supplemental metadata stays readable,
answer labels stay primary, and question fitting retains its own measured viewport.
The Eve/Device preference remains implemented by FontManager and the device-font
overlay. No font assets or preference logic change in this migration.

Production screen traces and the earlier native-fixture methodology remain in
[EVE_STUDENT_UI_COVERAGE.md](EVE_STUDENT_UI_COVERAGE.md) and
[EVE_ADMIN_UI_COVERAGE.md](EVE_ADMIN_UI_COVERAGE.md). Their older numeric shape or
Home-background descriptions are superseded by this contract, ADR-009 and ADR-012. Canvas
fixtures, full-window screenshots and authenticated production flows are distinct
forms of evidence; report them separately.
