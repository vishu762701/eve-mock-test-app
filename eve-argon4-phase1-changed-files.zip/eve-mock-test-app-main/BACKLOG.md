# EVE Product & Engineering Backlog

Ranked by impact on user experience, stability, and design system fidelity per `ENGINEERING_STANDARD.md`.

## [COMPLETED] Phase 3: Official Apple iOS 26 Colors + Typography (Profile, Settings & Login)
- **Status**: Completed (2026-10-13)
- **Scope**: `activity_profile.xml`, `ProfileActivity.kt`, `activity_settings.xml`, `SettingsActivity.kt`, `bottom_sheet_font_picker.xml`, `activity_login.xml`, `LoginActivity.kt`.
- **Details**: Full migration of Profile, Settings, and Login screens to canonical Apple iOS 26 semantic color roles, typography hierarchy, adaptive switch green, zero hardcoded text sizes, and comprehensive automated JVM verification.

## [COMPLETED] Phase 4: Official Apple iOS 26 Typography Migration for Mock Test Screen
- **Status**: Completed (2026-10-13)
- **Scope**: `activity_test.xml`, `item_question.xml`, `item_palette_circle.xml`, `CircularTimerView.kt`, `type.xml`.
- **Details**: Standardized question text to Callout (16sp, lineSpacingMultiplier 1.5), option labels (A–D) to Subheadline (14sp), per-question timer chip to Footnote.Medium (13sp), palette circle numbers to Caption1.Medium (12sp), screen title to Headline (17sp), loading/message states to semantic roles, 0 hardcoded text sizes, and preserved all rigid 2x2 geometry, server scoring, and answer state colors.

## [COMPLETED] Phase 5: Official Apple iOS 26 Typography Migration for Result & Secondary Screens
- **Status**: Completed (2026-10-13)
- **Scope**: `activity_result.xml`, `activity_result_detail.xml`, `item_answer.xml`, `item_result_topic.xml`, `item_topic_stat.xml`, `ResultDetailActivity.kt`, `ResultAnalysisRows.kt`, `activity_leaderboard.xml`, `item_leaderboard.xml`, `activity_history.xml`, `item_history.xml`, `activity_syllabus.xml`, `item_syllabus.xml`, `activity_feedback.xml`, `item_feedback_message.xml`, `item_post_reply.xml`, `dialog_create_feedback_post.xml`, `dialog_reply_feedback.xml`, `dialog_report_question.xml`, `activity_about.xml`, `activity_content_display.xml`.
- **Details**: Full migration of Result (Overview, Statistics, Performance, Analytics, Review), Leaderboard, History, Syllabus, Feedback, and About screens to canonical Apple iOS 26 typography hierarchy and semantic color roles. 100% elimination of hardcoded text sizes across 19 layouts. Leaderboard visual geometry strictly preserved with zero redesign. Comprehensive automated JVM test suite (`ResultAndSecondaryScreensTypographyTest.kt`).

## [COMPLETED] App-wide Apple iOS 26 Dynamic Typography & 26 Colour Roles (All 95 Layouts)
- **Status**: Completed (2026-10-13)
- **Scope**: All 95 Android layouts in `app/src/main/res/layout/`, `attrs.xml`, `themes.xml`, `type.xml`, ADR-008 (`DECISIONS.md`), `AppWideTypographyAndColorRolesTest.kt`.
- **Details**: Full migration of all remaining layouts (student secondary, monetization, core admin dashboard, admin management, admin forms, admin item rows, and admin dialogs). Codified all 26 authoritative Apple iOS colour roles in `attrs.xml` and `themes.xml`. Achieved 100% elimination of hardcoded `android:textSize` attributes project-wide (0 remaining across all 95 layout files). Automated verification suite added in `AppWideTypographyAndColorRolesTest.kt`. Preserved pure `#FFFFFF` / `#000000` canvas, Telegram transitions, test engine, and asset invariants.

## [COMPLETED] EVE JARVIS Gemini Gem Google Drive Synchronization Pipeline (ADR-009 & ADR-010)
- **Status**: Completed (2026-10-14)
- **Scope**: `.github/workflows/sync-jarvis-gemini.yml`, `.github/scripts/gdrive-sync/`, `docs/EVE_JARVIS_GEMINI_SYNC_SETUP.md`, ADR-009, ADR-010 (`DECISIONS.md`).
- **Details**: Built the complete, secure, autonomous GitHub-to-Google-Drive synchronization pipeline for EVE JARVIS Gemini Gem. Features Dual-Mode Authentication (Option A: Google User OAuth 2.0 with personal quota; Option B: Service Account for Workspace Shared Drives), 7-volume knowledge consolidation under the Gemini Gem 10-file cap, line-numbered source code with exact commit SHA headers, stable Google Drive document ID preservation via in-place `files.update`, atomic publication with partial failure rollback protection (master index published only when all 6 volumes succeed), exponential backoff with randomized jitter on 429/5xx, transparent 401 token refresh, universal Shared Drive support (`supportsAllDrives=true`), SHA consistency with Android APK builds, automated secret sanitization across adversarial strings, and a zero-dependency OAuth setup helper (`oauth-helper.mjs`). Verified via 25 automated unit tests (`node:test`).

## [P3] Accessibility: Extreme Font Scale (1.78x / 2.0x) Audit
- **Impact**: Low-Medium
- **Scope**: Navigation drawer list items in `activity_main.xml` and form layouts.
- **Details**: Verify text wrapping on narrow devices (320dp) under maximum system font scales to ensure UI rows remain cleanly accessible with zero overlap.

## [P1] iOS 26 migration: physical-device verification
- **Scope**: Device compositor blur, clear Sign In outside area, pre-31 fallback, live account/exam flows, and Eve/Device font appearance.
- **Details**: Both API 35 native navigation suites pass (34 tests each), with complete light/dark evidence gates. Requested chrome/modal and Home/Test/Result/Settings/Login captures were reviewed with fixture limitations recorded in docs/ios26/MIGRATION_REPORT.md. Inspect the remaining hardware and live-flow behavior on physical devices; emulator/Canvas evidence does not certify these items.

## [COMPLETED — CODE & LOCAL VERIFICATION] Argon 4 — Eve Phase 1: App-Wide Background and Tab-Chrome Correction (ADR-012)
- **Status**: Implemented (2026-10-15; `DONE-UNVERIFIED` pending Android SDK / emulator run in CI)
- **Scope**: `colors.xml` (Day/Night), `approved_ui_colors.xml` (Day/Night), `attrs.xml`, `styles.xml`, `SystemBarHelper.kt`, `EveBaseActivity.kt`, `EveGlassToolbar.kt`, `EveGlassTabLayout.kt`, `EveGlassSegmentedControl.kt`, `EveBlurHelper.kt`, `ResultTabs.kt`, `bg_tab_segmented_track.xml`, `bg_tab_segmented_indicator.xml`, 9 grouped Activity classes, 25 layout XML files, and regression tests (`Argon4Phase1BackgroundAndTabChromeTest.kt`, `AppWideTypographyAndColorRolesTest.kt`, `ManualBorderInventoryTest.kt`, `ApprovedUiRenderingTest.kt`, `Ios26ChromeTest.kt`, `check_design_system.py`, `test_design_system.py`).
- **Remaining out-of-scope / next items**:
  1. **[P1] Run CI / device native verification**: Execute `gradle assembleDebug lintDebug testDebugUnitTest assembleDebugAndroidTest` and both `gesture` / `three-button` emulator suites on API 35+ and physical devices.
  2. **[P2] Legacy `Eve.TopBar` / `Eve.Screen` styles in `styles.xml`**: Currently unused by any layout, but still reference `@color/eve_bg`; keep out of Phase 1 scope unless future cleanup is requested.
  3. **[P2] Individual header action icon buttons (`bg_circle_translucent`)**: Some headers (`Result`, `Leaderboard`, `Profile`, `Settings`) use `bg_circle_translucent` on back/share buttons while others use `?attr/selectableItemBackgroundBorderless`; explicitly left untouched per Phase 1 rule ("Do not create new individual glass buttons as part of this cleanup").
