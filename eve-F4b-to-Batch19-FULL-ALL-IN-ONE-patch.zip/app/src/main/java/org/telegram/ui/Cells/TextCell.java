/*
 * This is the source code of Telegram for Android v. 5.x.x.
 * It is licensed under GNU GPL v. 2 or later.
 * You should have received a copy of the license in this archive (see LICENSE).
 *
 * Copyright Nikolai Kudashov, 2013-2018.
 */

package org.telegram.ui.Cells;

import static org.telegram.messenger.AndroidUtilities.dp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.ImageView;


import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.FileLog;
import org.telegram.messenger.LocaleController;
import org.telegram.ui.ActionBar.SimpleTextView;
import org.telegram.ui.ActionBar.Theme;
import org.telegram.ui.Components.AnimatedTextView;
import org.telegram.ui.Components.LayoutHelper;
import org.telegram.ui.Components.Switch;

public class TextCell extends FrameLayout implements Theme.Colorable {

    public final SimpleTextView textView;
    private final SimpleTextView subtitleView;
    public final AnimatedTextView valueTextView;
    public final SimpleTextView valueSpoilersTextView;
    public final ImageView imageView; // EVE-PATCH: use standard ImageView without RLottie
    private Switch checkBox;
    private ImageView valueImageView;
    public int leftPadding;
    private boolean needDivider;
    public int offsetFromImage = 71;
    public int heightDp = 50;
    public int imageLeft = 21;
    private boolean inDialogs;
    private boolean prioritizeTitleOverValue;
    private Theme.ResourcesProvider resourcesProvider;
    private boolean attached;
    private int loadingSize;
    private boolean drawLoading;
    private boolean measureDelay;
    private float loadingProgress;
    private float drawLoadingProgress;

    private int lastWidth;

    public TextCell(Context context) {
        this(context, 20, false, false, null);
    }

    public TextCell(Context context, Theme.ResourcesProvider resourcesProvider) {
        this(context, 20, false, false, resourcesProvider);
    }

    public TextCell(Context context, int left, boolean dialog) {
        this(context, left, dialog, false, null);
    }

    public TextCell(Context context, int left, boolean dialog, boolean needCheck, Theme.ResourcesProvider resourcesProvider) {
        super(context);

        this.resourcesProvider = resourcesProvider;
        leftPadding = left;

        textView = new SimpleTextView(context);
        textView.setTextColor(Theme.getColor(dialog ? Theme.key_dialogTextBlack : Theme.key_windowBackgroundWhiteBlackText, resourcesProvider)); // EVE-PATCH: direct text color without ThemeBind
        textView.setTextSize(16);
        textView.setGravity(LocaleController.isRTL ? Gravity.RIGHT : Gravity.LEFT);
        textView.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        addView(textView, LayoutHelper.createFrame(LayoutHelper.WRAP_CONTENT, LayoutHelper.MATCH_PARENT));

        subtitleView = new SimpleTextView(context);
        subtitleView.setTextColor(Theme.getColor(dialog ? Theme.key_dialogTextGray : Theme.key_windowBackgroundWhiteGrayText, resourcesProvider)); // EVE-PATCH: direct subtitle color without ThemeBind
        subtitleView.setTextSize(13);
        subtitleView.setGravity(LocaleController.isRTL ? Gravity.RIGHT : Gravity.LEFT);
        subtitleView.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        addView(subtitleView, LayoutHelper.createFrame(LayoutHelper.WRAP_CONTENT, LayoutHelper.MATCH_PARENT));

        valueTextView = new AnimatedTextView(context, false, true, true);
        valueTextView.setTextColor(Theme.getColor(dialog ? Theme.key_dialogTextBlue2 : Theme.key_windowBackgroundWhiteValueText, resourcesProvider)); // EVE-PATCH: direct value color without ThemeBind
        valueTextView.setPadding(0, dp(18), 0, dp(18));
        valueTextView.setTextSize(dp(16));
        valueTextView.setGravity(LocaleController.isRTL ? Gravity.LEFT : Gravity.RIGHT);
        valueTextView.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        valueTextView.setTranslationY(dp(-2));
        addView(valueTextView);

        valueSpoilersTextView = new SimpleTextView(context);
        valueSpoilersTextView.setEllipsizeByGradient(18, false);
        valueSpoilersTextView.setTextColor(Theme.getColor(dialog ? Theme.key_dialogTextBlue2 : Theme.key_windowBackgroundWhiteValueText, resourcesProvider)); // EVE-PATCH: direct value color without ThemeBind
        valueSpoilersTextView.setGravity(LocaleController.isRTL ? Gravity.LEFT : Gravity.RIGHT);
        valueSpoilersTextView.setTextSize(16);
        valueSpoilersTextView.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        valueSpoilersTextView.setVisibility(GONE);
        addView(valueSpoilersTextView);

        imageView = new ImageView(context); // EVE-PATCH: use standard ImageView
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        imageView.setColorFilter(new PorterDuffColorFilter(Theme.getColor(dialog ? Theme.key_dialogIcon : Theme.key_windowBackgroundWhiteGrayIcon, resourcesProvider), PorterDuff.Mode.SRC_IN)); // EVE-PATCH: direct icon color filter without ThemeBind
        addView(imageView);

        valueImageView = new ImageView(context);
        valueImageView.setScaleType(ImageView.ScaleType.CENTER);
        addView(valueImageView);

        if (needCheck) {
            checkBox = new Switch(context, resourcesProvider);
            checkBox.setColors(Theme.key_switchTrack, Theme.key_switchTrackChecked, Theme.key_windowBackgroundWhite, Theme.key_windowBackgroundWhite);
            addView(checkBox, LayoutHelper.createFrame(37, 20, (LocaleController.isRTL ? Gravity.LEFT : Gravity.RIGHT) | Gravity.CENTER_VERTICAL, 22, 0, 22, 0));
        }

        setFocusable(true);
    }

    public boolean isChecked() {
        return checkBox != null && checkBox.isChecked();
    }

    public Switch getCheckBox() {
        return checkBox;
    }

    public void setIsInDialogs() {
        inDialogs = true;
    }

    public SimpleTextView getTextView() {
        return textView;
    }

    public ImageView getImageView() { // EVE-PATCH: return standard ImageView
        return imageView;
    }

    public AnimatedTextView getValueTextView() {
        return valueTextView;
    }

    public ImageView getValueImageView() {
        return valueImageView;
    }

    public void setPrioritizeTitleOverValue(boolean prioritizeTitleOverValue) {
        if (this.prioritizeTitleOverValue != prioritizeTitleOverValue) {
            this.prioritizeTitleOverValue = prioritizeTitleOverValue;
            requestLayout();
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = dp(heightDp);

        if (lastWidth != 0 && lastWidth != width && valueText != null) {
            valueTextView.setText(TextUtils.ellipsize(valueText, valueTextView.getPaint(), AndroidUtilities.displaySize.x / 2.5f, TextUtils.TruncateAt.END), false);
        }
        lastWidth = width;

        int valueWidth;
        if (prioritizeTitleOverValue) {
            textView.measure(MeasureSpec.makeMeasureSpec(width - dp(71 + leftPadding), MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.EXACTLY));
            subtitleView.measure(MeasureSpec.makeMeasureSpec(width - dp(71 + leftPadding), MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.EXACTLY));
            valueTextView.measure(MeasureSpec.makeMeasureSpec(width - dp(103 + leftPadding) - textView.getTextWidth(), LocaleController.isRTL ? MeasureSpec.AT_MOST : MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.EXACTLY));
            valueSpoilersTextView.measure(MeasureSpec.makeMeasureSpec(width - dp(103 + leftPadding) - textView.getTextWidth(), LocaleController.isRTL ? MeasureSpec.AT_MOST : MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.EXACTLY));
        } else {
            valueTextView.measure(MeasureSpec.makeMeasureSpec(width - dp(leftPadding), LocaleController.isRTL ? MeasureSpec.AT_MOST : MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.EXACTLY));
            valueSpoilersTextView.measure(MeasureSpec.makeMeasureSpec(width - dp(leftPadding), LocaleController.isRTL ? MeasureSpec.AT_MOST : MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.EXACTLY));
            valueWidth = Math.max(valueTextView.width(), valueSpoilersTextView.getTextWidth());
            textView.measure(MeasureSpec.makeMeasureSpec(Math.max(0, width - dp(71 + leftPadding) - valueWidth), MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.EXACTLY));
            subtitleView.measure(MeasureSpec.makeMeasureSpec(width - dp(71 + leftPadding) - valueWidth, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.EXACTLY));
        }
        if (imageView.getVisibility() == VISIBLE) {
            imageView.measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(height, MeasureSpec.AT_MOST));
        }
        if (valueImageView.getVisibility() == VISIBLE) {
            valueImageView.measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(height, MeasureSpec.AT_MOST));
        }
        if (checkBox != null) {
            checkBox.measure(MeasureSpec.makeMeasureSpec(dp(37), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(dp(20), MeasureSpec.EXACTLY));
        }
        setMeasuredDimension(width, height + (needDivider ? 1 : 0));
    }

    @Override
    public void setEnabled(boolean enabled) {
        setEnabled(enabled, true);
    }

    public void setEnabled(boolean enabled, boolean animated) {
        super.setEnabled(enabled);
        if (checkBox != null) {
            checkBox.setEnabled(enabled);
        }
        if (animated) {
            textView.animate().alpha(enabled ? 1.0f : 0.5f).start();
            subtitleView.animate().alpha(enabled ? 1.0f : 0.5f).start();
            valueTextView.animate().alpha(enabled ? 1.0f : 0.5f).start();
            valueSpoilersTextView.animate().alpha(enabled ? 1.0f : 0.5f).start();
        } else {
            textView.setAlpha(enabled ? 1.0f : 0.5f);
            subtitleView.setAlpha(enabled ? 1.0f : 0.5f);
            valueTextView.setAlpha(enabled ? 1.0f : 0.5f);
            valueSpoilersTextView.setAlpha(enabled ? 1.0f : 0.5f);
        }
    }

    public void updateEmojiBounds() {
        if (emojiDrawable == null) return;
        emojiDrawable.setBounds(
            getWidth() - emojiDrawable.getIntrinsicWidth() - AndroidUtilities.dp(18),
            (getHeight() - emojiDrawable.getIntrinsicHeight()) / 2,
            getWidth() - AndroidUtilities.dp(18),
            (getHeight() + emojiDrawable.getIntrinsicHeight()) / 2
        );
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        int height = bottom - top;
        int width = right - left;

        int viewTop = (height - Math.max(valueSpoilersTextView.getTextHeight(), valueTextView.getTextHeight())) / 2 + 1;
        int viewLeft = LocaleController.isRTL ? dp(leftPadding - 6) : width - valueTextView.getMeasuredWidth() - dp(leftPadding - 6);
        if (prioritizeTitleOverValue && !LocaleController.isRTL) {
            viewLeft = width - valueTextView.getMeasuredWidth() - dp(leftPadding);
        }
        valueTextView.layout(viewLeft, viewTop, viewLeft + valueTextView.getMeasuredWidth(), viewTop + valueTextView.getMeasuredHeight());
        viewLeft = LocaleController.isRTL ? dp(leftPadding - 6) : width - valueSpoilersTextView.getMeasuredWidth() - dp(leftPadding - 6);
        valueSpoilersTextView.layout(viewLeft, viewTop, viewLeft + valueSpoilersTextView.getMeasuredWidth(), viewTop + valueSpoilersTextView.getMeasuredHeight());

        if (LocaleController.isRTL) {
            viewLeft = getMeasuredWidth() - textView.getMeasuredWidth() - dp(imageView.getVisibility() == VISIBLE ? offsetFromImage : leftPadding);
        } else {
            viewLeft = dp(imageView.getVisibility() == VISIBLE ? offsetFromImage : leftPadding);
        }
        if (subtitleView.getVisibility() == View.VISIBLE) {
            int margin = heightDp > 50 ? 4 : 2;
            viewTop = (height - textView.getTextHeight() - subtitleView.getTextHeight() - dp(margin)) / 2 + dp(1);
            textView.layout(viewLeft, viewTop, viewLeft + textView.getMeasuredWidth(), viewTop + textView.getMeasuredHeight());
            viewTop = viewTop + textView.getTextHeight() + dp(margin);
            subtitleView.layout(viewLeft, viewTop, viewLeft + subtitleView.getMeasuredWidth(), viewTop + subtitleView.getMeasuredHeight());
        } else {
            viewTop = (height - textView.getTextHeight()) / 2 + dp(1);
            textView.layout(viewLeft, viewTop, viewLeft + textView.getMeasuredWidth(), viewTop + textView.getMeasuredHeight());
        }
        if (imageView.getVisibility() == VISIBLE) {
            viewTop = dp(heightDp > 50 ? 0 : 2) + (height - imageView.getMeasuredHeight()) / 2 - imageView.getPaddingTop() + dp(1);
            viewLeft = !LocaleController.isRTL ? dp(imageLeft) : width - imageView.getMeasuredWidth() - dp(imageLeft);
            imageView.layout(viewLeft, viewTop, viewLeft + imageView.getMeasuredWidth(), viewTop + imageView.getMeasuredHeight());
        }

        if (valueImageView.getVisibility() == VISIBLE) {
            viewTop = (height - valueImageView.getMeasuredHeight()) / 2 + dp(1);
            viewLeft = LocaleController.isRTL ? dp(23) : width - valueImageView.getMeasuredWidth() - dp(23);
            valueImageView.layout(viewLeft, viewTop, viewLeft + valueImageView.getMeasuredWidth(), viewTop + valueImageView.getMeasuredHeight());
        }
        if (checkBox != null && checkBox.getVisibility() == VISIBLE) {
            viewTop = (height - checkBox.getMeasuredHeight()) / 2;
            viewLeft = LocaleController.isRTL ? dp(22) : width - checkBox.getMeasuredWidth() - dp(22);
            checkBox.layout(viewLeft, viewTop, viewLeft + checkBox.getMeasuredWidth(), viewTop + checkBox.getMeasuredHeight());
        }
    }

    public void setTextColor(int color) {
        textKeyColors = false;
        textView.setTextColor(color);
    }

    // set by setColors: theme switches re-apply the tagged keys (through processColor) until a raw color replaces them
    private boolean textKeyColors, iconKeyColors;

    protected int processColor(int color) {
        return color;
    }

    private int lastIconKeyColor;
    private android.graphics.ColorFilter lastIconKeyFilter;

    private void applyColorKeys() {
        int textKey = textView.getTag() instanceof Integer ? (int) textView.getTag() : Theme.key_windowBackgroundWhiteBlackText;
        int textColor = Theme.getColor(textKey, resourcesProvider);
        if (textKey != Theme.key_dialogTextBlack && textKey != Theme.key_windowBackgroundWhiteBlackText) {
            textColor = processColor(textColor);
        }
        if (textKeyColors) {
            textView.setTextColor(textColor);
        }
        if (iconKeyColors && imageView.getTag() instanceof Integer) {
            int colorKey = (int) imageView.getTag();
            int color = Theme.getColor(colorKey, resourcesProvider);
            if (colorKey != Theme.key_dialogIcon && colorKey != Theme.key_windowBackgroundWhiteGrayIcon) {
                color = processColor(color);
            }
            if (color != lastIconKeyColor || imageView.getColorFilter() != lastIconKeyFilter) {
                lastIconKeyColor = color;
                imageView.setColorFilter(lastIconKeyFilter = new PorterDuffColorFilter(color, PorterDuff.Mode.SRC_IN));
            }
        }
        subtitleView.setTextColor(processColor(Theme.getColor(Theme.key_windowBackgroundWhiteGrayText, resourcesProvider)));
        valueTextView.setTextColor(processColor(Theme.getColor(Theme.key_windowBackgroundWhiteValueText, resourcesProvider)));
        valueSpoilersTextView.setTextColor(processColor(Theme.getColor(Theme.key_windowBackgroundWhiteValueText, resourcesProvider)));
    }

    public void setColors(int icon, int text) {
        textView.setTextColor(Theme.getColor(text, resourcesProvider));
        textView.setTag(text);
        textKeyColors = true;
        if (icon >= 0) {
            imageView.setColorFilter(new PorterDuffColorFilter(Theme.getColor(icon, resourcesProvider), PorterDuff.Mode.SRC_IN));
            imageView.setTag(icon);
            iconKeyColors = true;
        }
        applyColorKeys();
    }

    /** theme switches (Theme.Colorable): only colors that came from setColors keys follow the theme */
    @Override
    public void updateColors() {
        if (!textKeyColors && !iconKeyColors) {
            // explicit callers (peer color previews) rely on processColor overrides for the subtitle / value colors
            try {
                final int subtitle = Theme.getColor(Theme.key_windowBackgroundWhiteGrayText, resourcesProvider);
                final int value = Theme.getColor(Theme.key_windowBackgroundWhiteValueText, resourcesProvider);
                final int processedSubtitle = processColor(subtitle), processedValue = processColor(value);
                if (processedSubtitle != subtitle || processedValue != value) {
                    subtitleView.setTextColor(processedSubtitle);
                    valueTextView.setTextColor(processedValue);
                    valueSpoilersTextView.setTextColor(processedValue);
                }
            } catch (Exception e) {
                FileLog.e(e);
            }
            return;
        }
        try {
            applyColorKeys();
        } catch (Exception e) {
            FileLog.e(e);
        }
    }

    private CharSequence valueText;

    public void setText(CharSequence text, boolean divider) {
        imageLeft = getDefaultImageLeft();
        textView.setText(text);
        textView.setRightDrawable(null);
        valueTextView.setText(valueText = null, false);
        imageView.setVisibility(GONE);
        valueTextView.setVisibility(GONE);
        valueSpoilersTextView.setVisibility(GONE);
        valueImageView.setVisibility(GONE);
        needDivider = divider;
        setWillNotDraw(!needDivider);
    }

    public void setTextAndIcon(CharSequence text, int resId, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        valueTextView.setText(valueText = null, false);
        imageView.setImageResource(resId);
        imageView.setVisibility(VISIBLE);
        valueTextView.setVisibility(GONE);
        valueSpoilersTextView.setVisibility(GONE);
        valueImageView.setVisibility(GONE);
        imageView.setPadding(0, dp(7), 0, 0);
        needDivider = divider;
        setWillNotDraw(!needDivider);
    }

    public void setTextAndColorfulIcon(CharSequence text, int resId, int color, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        valueTextView.setText(valueText = null, false);
        setColorfulIcon(color, resId);
        valueTextView.setVisibility(GONE);
        valueImageView.setVisibility(GONE);
        needDivider = divider;
        setWillNotDraw(!needDivider);
    }

    public void setTextAndIcon(CharSequence text, Drawable drawable, boolean divider) { imageView.setImageDrawable(drawable); // EVE-PATCH: set drawable directly on ImageView
        offsetFromImage = getOffsetFromImage(false);
        imageLeft = 18;
        textView.setText(text);
        textView.setRightDrawable(null);
        valueTextView.setText(valueText = null, false);
        imageView.setColorFilter(null);
        imageView.setVisibility(VISIBLE);
        valueTextView.setVisibility(GONE);
        valueImageView.setVisibility(GONE);
        imageView.setPadding(0, dp(6), 0, 0);
        needDivider = divider;
        setWillNotDraw(!needDivider);
    }

    public void setTextAndValueAndIcon(CharSequence text, CharSequence value, Drawable drawable, boolean divider) { imageView.setImageDrawable(drawable); // EVE-PATCH: set drawable directly on ImageView
        offsetFromImage = getOffsetFromImage(false);
        imageLeft = 18;
        textView.setText(text);
        textView.setRightDrawable(null);
        valueTextView.setText(valueText = value, false);
        imageView.setColorFilter(null);
        imageView.setVisibility(VISIBLE);
        valueTextView.setVisibility(VISIBLE);
        valueImageView.setVisibility(GONE);
        imageView.setPadding(0, dp(6), 0, 0);
        needDivider = divider;
        setWillNotDraw(!needDivider);
    }

    public void setOffsetFromImage(int value) {
        offsetFromImage = value;
    }

    public void setImageLeft(int imageLeft) {
        this.imageLeft = imageLeft;
    }

    public void setTextAndValue(CharSequence text, CharSequence value, boolean divider) {
        setTextAndValue(text, value, false, divider);
    }

    public void setTextAndValue(CharSequence text, CharSequence value, boolean animated, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        valueText = value;
        valueTextView.setText(valueText == null ? null : TextUtils.ellipsize(valueText, valueTextView.getPaint(), AndroidUtilities.displaySize.x / 2.5f, TextUtils.TruncateAt.END), animated);
        valueTextView.setVisibility(VISIBLE);
        valueSpoilersTextView.setVisibility(GONE);
        imageView.setVisibility(GONE);
        valueImageView.setVisibility(GONE);
        needDivider = divider;
        setWillNotDraw(!needDivider);
        if (checkBox != null) {
            checkBox.setVisibility(GONE);
        }
    }

    public void setValue(CharSequence value, boolean animated) {
        valueTextView.setText(value == null ? "" : TextUtils.ellipsize(valueText = value, valueTextView.getPaint(), AndroidUtilities.displaySize.x / 2.5f, TextUtils.TruncateAt.END), animated);
    }

    public void setTextAndValueAndColorfulIcon(String text, CharSequence value, boolean animated, int resId, int colorTop, int colorBottom, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        valueTextView.setText(value == null ? "" : TextUtils.ellipsize(valueText = value, valueTextView.getPaint(), AndroidUtilities.displaySize.x / 2.5f, TextUtils.TruncateAt.END), animated);
        valueTextView.setVisibility(VISIBLE);
        valueSpoilersTextView.setVisibility(GONE);
        setColorfulIcon(colorTop, colorBottom, resId);
        valueImageView.setVisibility(GONE);
        needDivider = divider;
        setWillNotDraw(!needDivider);
        if (checkBox != null) {
            checkBox.setVisibility(GONE);
        }
    }

    public void setTextAndCheckAndColorfulIcon(CharSequence text, boolean checked, int resId, int color, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        valueTextView.setVisibility(GONE);
        valueSpoilersTextView.setVisibility(GONE);
        valueImageView.setVisibility(GONE);
        setColorfulIcon(color, resId);
        if (checkBox == null) {
            checkBox = new Switch(getContext(), resourcesProvider);
            checkBox.setColors(Theme.key_switchTrack, Theme.key_switchTrackChecked, Theme.key_windowBackgroundWhite, Theme.key_windowBackgroundWhite);
            addView(checkBox, LayoutHelper.createFrame(37, 20, (LocaleController.isRTL ? Gravity.LEFT : Gravity.RIGHT) | Gravity.CENTER_VERTICAL, 22, 0, 22, 0));
        }
        if (checkBox != null) {
            checkBox.setVisibility(VISIBLE);
            checkBox.setChecked(checked, false);
        }
        needDivider = divider;
        setWillNotDraw(!needDivider);
    }

    public void setTextAndSpoilersValueAndIcon(String text, CharSequence value, int resId, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        valueSpoilersTextView.setVisibility(VISIBLE);
        valueSpoilersTextView.setText(value);
        valueTextView.setVisibility(GONE);
        valueImageView.setVisibility(GONE);
        imageView.setVisibility(VISIBLE);
        imageView.setTranslationX(0);
        imageView.setTranslationY(0);
        imageView.setPadding(0, dp(7), 0, 0);
        imageView.setImageResource(resId);
        needDivider = divider;
        setWillNotDraw(!needDivider);
        if (checkBox != null) {
            checkBox.setVisibility(GONE);
        }
    }

    public void setTextAndSpoilersValueAndColorfulIcon(String text, CharSequence value, int resId, int color, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        valueSpoilersTextView.setVisibility(VISIBLE);
        valueSpoilersTextView.setText(value);
        valueTextView.setVisibility(GONE);
        setColorfulIcon(color, resId);
        valueImageView.setVisibility(GONE);
        needDivider = divider;
        setWillNotDraw(!needDivider);
        if (checkBox != null) {
            checkBox.setVisibility(GONE);
        }
    }

    public void setTextAndValueAndIcon(CharSequence text, CharSequence value, int resId, boolean divider) {
        setTextAndValueAndIcon(text, value, false, resId, divider);
    }

    public void setTextAndCheck(CharSequence text, boolean checked, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        imageView.setVisibility(GONE);
        valueImageView.setVisibility(GONE);
        needDivider = divider;
        if (checkBox != null) {
            checkBox.setVisibility(VISIBLE);
            checkBox.setChecked(checked, false);
        }
        setWillNotDraw(!needDivider);
    }

    public void setTextAndCheckAndIcon(CharSequence text, boolean checked, int resId, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        valueTextView.setVisibility(GONE);
        valueSpoilersTextView.setVisibility(GONE);
        valueImageView.setVisibility(GONE);
        if (checkBox != null) {
            checkBox.setVisibility(VISIBLE);
            checkBox.setChecked(checked, false);
        }
        imageView.setVisibility(VISIBLE);
        imageView.setPadding(0, dp(7), 0, 0);
        imageView.setImageResource(resId);
        needDivider = divider;
        setWillNotDraw(!needDivider);
    }

    public void setTextAndCheckAndIcon(String text, boolean checked, Drawable resDrawable, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        valueTextView.setVisibility(GONE);
        valueSpoilersTextView.setVisibility(GONE);
        valueImageView.setVisibility(GONE);
        if (checkBox != null) {
            checkBox.setVisibility(VISIBLE);
            checkBox.setChecked(checked, false);
        }
        imageView.setVisibility(VISIBLE);
        imageView.setPadding(0, dp(7), 0, 0);
        imageView.setImageDrawable(resDrawable);
        needDivider = divider;
        setWillNotDraw(!needDivider);
    }

    public void setTextAndValueDrawable(CharSequence text, Drawable drawable, boolean divider) {
        imageLeft = getDefaultImageLeft();
        offsetFromImage = getOffsetFromImage(false);
        textView.setText(text);
        textView.setRightDrawable(null);
        valueTextView.setText(valueText = null, false);
        valueImageView.setVisibility(VISIBLE);
        valueImageView.setImageDrawable(drawable);
        valueTextView.setVisibility(GONE);
        valueSpoilersTextView.setVisibility(GONE);
        imageView.setVisibility(GONE);
        imageView.setPadding(0, dp(7), 0, 0);
        needDivider = divider;
        setWillNotDraw(!needDivider);
        if (checkBox != null) {
            checkBox.setVisibility(GONE);
        }
    }

    private boolean compactLayout;

    public void setCompactLayout(boolean compact) {
        compactLayout = compact;
    }

    protected int getDefaultImageLeft() {
        return compactLayout ? 16 : 21;
    }

    protected int getOffsetFromImage(boolean colourful) {
        if (compactLayout) {
            return colourful ? 52 : 58;
        }
        return colourful ? 65 : 71;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (needDivider) {
            Paint paint = resourcesProvider != null ? resourcesProvider.getPaint(Theme.key_paint_divider) : null;
            if (paint == null) {
                paint = Theme.dividerPaint;
            }
            final int dividerLeft = dp(imageView.getVisibility() == VISIBLE ? (inDialogs ? 72 : offsetFromImage) : leftPadding);
            canvas.drawLine(LocaleController.isRTL ? 0 : dividerLeft, getMeasuredHeight() - 1, getMeasuredWidth() - (LocaleController.isRTL ? dividerLeft : 0), getMeasuredHeight() - 1, paint);
        }
    }

    @Override
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
        super.onInitializeAccessibilityNodeInfo(info);
        CharSequence text = textView.getText();
        if (!TextUtils.isEmpty(text)) {
            final CharSequence valueText = valueTextView.getText();
            if (!TextUtils.isEmpty(valueText)) {
                text = TextUtils.concat(text, ": ", valueText);
            }
        }
        if (checkBox != null) {
            info.setClassName("android.widget.Switch");
            info.setCheckable(true);
            info.setChecked(checkBox.isChecked());
            StringBuilder sb = new StringBuilder();
            sb.append(textView.getText());
            if (!TextUtils.isEmpty(valueTextView.getText())) {
                sb.append('\n');
                sb.append(valueTextView.getText());
            }
            info.setContentDescription(sb);
        } else {
            if (!TextUtils.isEmpty(text)) {
                info.setText(text);
            }
        }
        info.addAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    public void setNeedDivider(boolean needDivider) {
        if (this.needDivider != needDivider) {
            this.needDivider = needDivider;
            setWillNotDraw(!needDivider);
            invalidate();
        }
    }

    public void setChecked(boolean checked) {
        checkBox.setChecked(checked, true);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        attached = false;
    }

    public void setDrawLoading(boolean drawLoading, int size, boolean animated) {
        this.drawLoading = drawLoading;
        this.loadingSize = size;

        if (!animated) {
            drawLoadingProgress = drawLoading ? 1f : 0f;
        } else {
            measureDelay = true;
        }
        invalidate();
    }

    Paint paint;
    private boolean incrementLoadingProgress;
    private int changeProgressStartDelay;

    @Override
    protected void dispatchDraw(Canvas canvas) {
        if (drawLoading || drawLoadingProgress != 0) {
            if (paint == null) {
                paint = new Paint(Paint.ANTI_ALIAS_FLAG);
                paint.setColor(Theme.getColor(Theme.key_dialogSearchBackground, resourcesProvider));
            }
            //LocaleController.isRTL ? Gravity.LEFT : Gravity.RIGHT;
            if (incrementLoadingProgress) {
                loadingProgress += 16 / 1000f;
                if (loadingProgress > 1f) {
                    loadingProgress = 1f;
                    incrementLoadingProgress = false;
                }
            } else {
                loadingProgress -= 16 / 1000f;
                if (loadingProgress < 0) {
                    loadingProgress = 0;
                    incrementLoadingProgress = true;
                }
            }

            if (changeProgressStartDelay > 0) {
                changeProgressStartDelay -= 15;
            } else if (drawLoading && drawLoadingProgress != 1f) {
                drawLoadingProgress += 16 / 150f;
                if (drawLoadingProgress > 1f) {
                    drawLoadingProgress = 1f;
                }
            } else if (!drawLoading && drawLoadingProgress != 0) {
                drawLoadingProgress -= 16 / 150f;
                if (drawLoadingProgress < 0) {
                    drawLoadingProgress = 0;
                }
            }

            float alpha = (0.6f + 0.4f * loadingProgress) * drawLoadingProgress;
            paint.setAlpha((int) (255 * alpha));
            int cy = getMeasuredHeight() >> 1;
            AndroidUtilities.rectTmp.set(
                getMeasuredWidth() - dp(21) - dp(loadingSize),
                cy - dp(3),
                getMeasuredWidth() - dp(21),
                cy + dp(3)
            );
            if (LocaleController.isRTL) {
                AndroidUtilities.rectTmp.left = getMeasuredWidth() - AndroidUtilities.rectTmp.left;
                AndroidUtilities.rectTmp.right = getMeasuredWidth() - AndroidUtilities.rectTmp.right;
            }
            canvas.drawRoundRect(AndroidUtilities.rectTmp, dp(3), dp(3), paint);
            invalidate();
        }
        valueTextView.setAlpha((1f - drawLoadingProgress) * (emojiDrawable == null ? 1f : 1f - emojiDrawable.isNotEmpty()) * (isEnabled() ? 1.0f : 0.5f));
        valueSpoilersTextView.setAlpha((1f - drawLoadingProgress) * (emojiDrawable == null ? 1f : 1f - emojiDrawable.isNotEmpty()) * (isEnabled() ? 1.0f : 0.5f));
        super.dispatchDraw(canvas);
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            subtitleView.setVisibility(View.VISIBLE);
            subtitleView.setText(charSequence);
        } else {
            subtitleView.setVisibility(View.GONE);
        }
    }
}
